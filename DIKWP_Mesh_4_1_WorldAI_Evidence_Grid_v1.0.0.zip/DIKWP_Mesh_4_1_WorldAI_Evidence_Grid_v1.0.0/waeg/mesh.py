from __future__ import annotations

from collections import defaultdict, deque
from typing import Any, Callable

from .constants import DIKWP_CHANNELS
from .util import make_id, utc_now


def build_mesh(
    capsule: dict[str, Any],
    output: dict[str, Any],
    evaluation: dict[str, Any],
    crosswalk: list[dict[str, Any]],
    *,
    observer: str,
) -> dict[str, Any]:
    now = utc_now()
    context = {"capsule_id": capsule["id"], "jurisdiction": capsule.get("authority", {}).get("jurisdiction"), "data_locality": capsule.get("authority", {}).get("data_locality")}
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []

    def node(node_id: str, role: str, kind: str, label: str, source_state: str, payload_ref: str) -> None:
        nodes.append({"id": node_id, "role": role, "kind": kind, "label": label, "source_state": source_state, "observer": observer, "context": context, "time": now, "payload_ref": payload_ref})

    def edge(source: str, target: str, channel: str, relation: str, source_state: str, provenance: str) -> None:
        edges.append({"id": make_id("edge"), "source": source, "target": target, "channel": channel, "relation": relation, "source_state": source_state, "observer": observer, "context": context, "time": now, "provenance": provenance})

    node("P-purpose", "P", "purpose_contract", capsule["purpose"]["statement"], capsule["purpose"].get("source_state", "absent"), "capsule.purpose")
    node("P-authority", "P", "authority", capsule.get("authority", {}).get("actor", "unknown"), "user_stipulated", "capsule.authority")
    node("I-manifest", "I", "run_manifest", f"{output.get('adapter')} / {output.get('model_ref')}", "runtime_observed", "run.manifest")
    node("W-gate", "W", "gate", evaluation["statuses"]["gate"], "runtime_derived", "evaluation.statuses.gate")
    node("W-review", "W", "human_review", str(capsule.get("authority", {}).get("human_review_required")), "user_stipulated", "capsule.authority.human_review_required")

    for item in capsule.get("inputs", []):
        nid = "D-input-" + item["id"]
        node(nid, "D", "input", item["id"], "source_supplied", f"capsule.inputs.{item['id']}")
        edge("P-purpose", nid, "P→D", "purpose_selects_declared_input", "runtime_compiled", "capsule purpose and input list")
        edge(nid, "I-manifest", "D→I", "input_hash_enters_run_manifest", "runtime_observed", item["sha256"])

    for task in output.get("tasks", []):
        tid = str(task.get("task_id", "unknown"))
        dnode = "D-output-" + tid
        inode = "I-claims-" + tid
        node(dnode, "D", "raw_output", tid, "adapter_observed", f"output.tasks.{tid}")
        node(inode, "I", "parsed_claims", f"claims:{len(task.get('claims', []))}", "runtime_parsed", f"output.tasks.{tid}.claims")
        edge("I-manifest", dnode, "I→D", "manifest_indexes_adapter_output", "runtime_observed", "run output")
        edge(dnode, inode, "D→I", "structured_output_is_parsed_without_hidden_inference", "runtime_parsed", "adapter output")
        edge(dnode, "P-purpose", "D→P", "output_purpose_ack_is_compared_with_contract", "runtime_tested", "purpose preservation check")
        edge("W-gate", dnode, "W→D", "gate_controls_publication_state_not_execution", "runtime_derived", "evaluation gate")
        for claim in task.get("claims", []):
            cid = str(claim.get("id", make_id("claim")))
            knode = "K-claim-" + cid
            node(knode, "K", "claim", str(claim.get("text", ""))[:300], str(claim.get("source_state", "adapter_generated")), f"output.claims.{cid}")
            edge(inode, knode, "I→K", "parsed_claim_enters_claim_evidence_examination", "runtime_parsed", "claim record")
            edge(knode, "W-gate", "K→W", "claim_evidence_state_contributes_to_gate", "runtime_derived", "evaluation checks")
            for ref in claim.get("evidence_refs", []):
                source_node = "D-input-" + str(ref)
                if any(n["id"] == source_node for n in nodes):
                    edge(source_node, knode, "D→K", "declared_evidence_reference_supports_claim_record", "adapter_declared", str(ref))

    for check_name, check in evaluation.get("checks", {}).items():
        knode = "K-check-" + check_name
        node(knode, "K", "evaluation_check", check_name, "runtime_derived", f"evaluation.checks.{check_name}")
        edge("I-manifest", knode, "I→K", "manifest_and_output_are_examined", "runtime_derived", check_name)
        edge(knode, "W-gate", "K→W", "check_state_contributes_to_gate", "runtime_derived", check_name)

    for profile in crosswalk:
        pnode = "K-profile-" + profile["profile_id"]
        node(pnode, "K", "crosswalk_profile", profile.get("title", profile["profile_id"]), profile.get("source_state", "source_limited"), f"crosswalk.{profile['profile_id']}")
        edge("I-manifest", pnode, "I→K", "run_artifacts_are_mapped_to_source_limited_controls", "runtime_derived", profile.get("profile_id", ""))
        edge(pnode, "W-review", "K→W", "crosswalk_gaps_remain_for_human_review", "runtime_derived", "no conformity claim")

    edge("P-authority", "P-purpose", "P→P", "authority_bounds_purpose_contract", "runtime_compiled", "capsule authority")
    edge("W-gate", "P-purpose", "W→P", "gate_preserves_or_suspends_current_purpose_closure", "runtime_derived", "gate state")
    edge("W-review", "P-purpose", "W→P", "human_review_requirement_bounds_closure", "runtime_compiled", "authority contract")

    validation_errors: list[str] = []
    node_ids = {n["id"] for n in nodes}
    for e in edges:
        if e["channel"] not in DIKWP_CHANNELS:
            validation_errors.append(f"invalid channel {e['channel']}")
        if e["source"] not in node_ids or e["target"] not in node_ids:
            validation_errors.append(f"edge {e['id']} has missing endpoint")
        for required in ("source_state", "observer", "context", "time", "provenance"):
            if not e.get(required):
                validation_errors.append(f"edge {e['id']} lacks {required}")

    channels = sorted({e["channel"] for e in edges})
    has_cycle = _has_cycle(node_ids, edges)
    required_cycle = all(channel in channels for channel in ("P→D", "D→I", "I→K", "K→W", "W→P"))
    residuals = []
    if len(channels) < 5:
        residuals.append("fewer than five relation channels are active")
    if not required_cycle:
        residuals.append("P→D→I→K→W→P closure path is incomplete")
    if not has_cycle:
        residuals.append("no directed cycle observed")
    if validation_errors:
        mesh_status = "M1"
    elif required_cycle and has_cycle and len(channels) >= 9:
        mesh_status = "M4"
    elif required_cycle and has_cycle:
        mesh_status = "M3"
    elif channels:
        mesh_status = "M2"
    else:
        mesh_status = "M0"
    return {
        "nodes": nodes,
        "edges": edges,
        "active_channels": channels,
        "inactive_channels": [channel for channel in DIKWP_CHANNELS if channel not in channels],
        "mesh_examination": mesh_status,
        "directed_cycle_observed": has_cycle,
        "closure_path_observed": required_cycle,
        "validation_errors": validation_errors,
        "residuals": residuals,
        "no_forced_25_cell_population": True,
        "boundary": "Channels are relation addresses activated by this run; they do not predefine universal meanings for D, I, K, W or P.",
    }


def _has_cycle(node_ids: set[str], edges: list[dict[str, Any]]) -> bool:
    graph: dict[str, list[str]] = defaultdict(list)
    indegree = {node: 0 for node in node_ids}
    for edge in edges:
        if edge["source"] in node_ids and edge["target"] in node_ids:
            graph[edge["source"]].append(edge["target"])
            indegree[edge["target"]] += 1
    queue = deque(node for node, degree in indegree.items() if degree == 0)
    seen = 0
    while queue:
        node = queue.popleft()
        seen += 1
        for target in graph[node]:
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    return seen < len(node_ids)


def counterfactual_kernel(
    facts: dict[str, Any],
    signature_fn: Callable[[dict[str, Any]], dict[str, Any]],
    mesh: dict[str, Any],
) -> dict[str, Any]:
    baseline = signature_fn(facts)
    kernel_facts: list[dict[str, Any]] = []
    for key in sorted(facts):
        value = facts[key]
        if not isinstance(value, bool) or not value:
            continue
        altered = dict(facts)
        altered[key] = False
        changed = signature_fn(altered)
        if changed != baseline:
            kernel_facts.append({"fact": key, "observed": value, "counterfactual": False, "baseline_signature": baseline, "counterfactual_signature": changed})
    relevant_terms = set()
    for item in kernel_facts:
        parts = item["fact"].replace("_present", "").replace("_declared", "").replace("_passed", "").split("_")
        relevant_terms.update(parts)
    kernel_nodes = []
    for node in mesh.get("nodes", []):
        text = (node.get("kind", "") + " " + node.get("label", "") + " " + node.get("payload_ref", "")).lower()
        if any(term and term in text for term in relevant_terms):
            kernel_nodes.append(node["id"])
    if not kernel_nodes:
        kernel_nodes = [n["id"] for n in mesh.get("nodes", []) if n.get("role") in {"P", "W"}]
    kernel_edges = [e["id"] for e in mesh.get("edges", []) if e.get("source") in kernel_nodes or e.get("target") in kernel_nodes]
    return {
        "baseline_signature": baseline,
        "critical_facts": kernel_facts,
        "kernel_node_ids": sorted(set(kernel_nodes)),
        "kernel_edge_ids": sorted(set(kernel_edges)),
        "scope": "current capsule, run, observer, source records, time and project-local evaluation rules only",
        "universal_essence_claim": False,
        "method": "Boolean evidence-fact deletion followed by closure-signature recomputation; no semantic salience ranking.",
    }
