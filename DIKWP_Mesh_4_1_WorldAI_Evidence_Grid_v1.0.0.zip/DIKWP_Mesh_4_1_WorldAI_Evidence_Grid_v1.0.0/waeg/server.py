from __future__ import annotations

import json
import mimetypes
import traceback
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from .adapters import AdapterError
from .auth import can, public_user
from .service import ConflictError, Service
from .util import canonical_json
from .validation import ValidationError

MAX_BODY = 5_000_000


class WAEGHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], handler: type[BaseHTTPRequestHandler], service: Service):
        super().__init__(address, handler)
        self.service = service
        self.web_root = service.root / "web"


class Handler(BaseHTTPRequestHandler):
    server_version = "WAEG/1.0"

    @property
    def service(self) -> Service:
        return self.server.service  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {self.client_address[0]} {fmt % args}")

    def _headers(self, status: int, content_type: str, length: int | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.end_headers()

    def _json(self, status: int, payload: Any) -> None:
        raw = (json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
        self._headers(status, "application/json; charset=utf-8", len(raw))
        self.wfile.write(raw)

    def _error(self, status: int, code: str, message: str, details: Any = None) -> None:
        payload = {"error": {"code": code, "message": message}}
        if details is not None:
            payload["error"]["details"] = details
        self._json(status, payload)

    def _body(self) -> Any:
        length_text = self.headers.get("Content-Length", "0")
        try:
            length = int(length_text)
        except ValueError as exc:
            raise ValidationError("invalid Content-Length", "headers") from exc
        if length < 0 or length > MAX_BODY:
            raise ValidationError(f"request body must not exceed {MAX_BODY} bytes", "body")
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValidationError("request body must be valid UTF-8 JSON", "body") from exc

    def _bearer(self) -> str:
        auth = self.headers.get("Authorization", "")
        if auth.lower().startswith("bearer "):
            return auth[7:].strip()
        return ""

    def _user(self, permission: str | None = None, *, public: bool = False) -> dict[str, Any]:
        if public:
            return public_user()
        user = self.service.db.user_for_token(self._bearer())
        if not user:
            raise PermissionError("authentication required")
        if permission and not can(user["role"], permission):
            raise PermissionError(f"role {user['role']} lacks permission {permission}")
        return user

    def _dispatch_error(self, exc: Exception) -> None:
        if isinstance(exc, PermissionError):
            self._error(HTTPStatus.FORBIDDEN, "forbidden", str(exc))
        elif isinstance(exc, KeyError):
            self._error(HTTPStatus.NOT_FOUND, "not_found", str(exc).strip("'"))
        elif isinstance(exc, (ValidationError, ValueError)):
            self._error(HTTPStatus.BAD_REQUEST, "validation_error", str(exc))
        elif isinstance(exc, ConflictError):
            self._error(HTTPStatus.CONFLICT, "revision_conflict", str(exc))
        elif isinstance(exc, AdapterError):
            self._error(HTTPStatus.UNPROCESSABLE_ENTITY, "adapter_error", str(exc))
        else:
            traceback.print_exc()
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "internal_error", "internal server error")

    def do_GET(self) -> None:  # noqa: N802
        try:
            parsed = urlparse(self.path)
            path = parsed.path
            query = parse_qs(parsed.query)
            if path == "/api/health":
                self._json(200, self.service.health())
                return
            if path.startswith("/api/"):
                user = self._user("read")
                if path == "/api/me":
                    self._json(200, user)
                elif path == "/api/adapters":
                    self._json(200, {"adapters": self.service.adapters()})
                elif path == "/api/portfolio":
                    self._json(200, self.service.portfolio(query.get("cluster", [None])[0], query.get("q", [None])[0]))
                elif path == "/api/capsules":
                    self._json(200, {"capsules": self.service.list_capsules()})
                elif path.startswith("/api/capsules/"):
                    self._json(200, self.service.get_capsule(path.split("/", 3)[3]))
                elif path == "/api/runs":
                    self._json(200, {"runs": self.service.list_runs(query.get("capsule_id", [None])[0], int(query.get("limit", [100])[0]))})
                elif path.startswith("/api/runs/"):
                    self._json(200, self.service.get_run(path.split("/", 3)[3]))
                elif path == "/api/compare":
                    left, right = query.get("left", [""])[0], query.get("right", [""])[0]
                    if not left or not right:
                        raise ValueError("left and right run ids are required")
                    self._json(200, self.service.compare_runs(left, right))
                elif path == "/api/crosswalks":
                    self._json(200, {"profiles": self.service.list_crosswalks()})
                elif path == "/api/nodes":
                    self._json(200, {"nodes": self.service.list_nodes()})
                elif path == "/api/challenges":
                    self._json(200, {"challenges": self.service.list_challenges(query.get("run_id", [None])[0])})
                elif path == "/api/imports":
                    self._json(200, {"imports": self.service.list_imports()})
                elif path == "/api/audit":
                    self._user("audit")
                    self._json(200, self.service.audit(int(query.get("limit", [200])[0])))
                elif path == "/api/summary":
                    self._json(200, {"counts": self.service.summary_counts(), "audit": self.service.db.verify_audit()})
                else:
                    self._error(404, "not_found", "API route not found")
                return
            self._serve_static(path)
        except Exception as exc:
            self._dispatch_error(exc)

    def do_POST(self) -> None:  # noqa: N802
        try:
            parsed = urlparse(self.path)
            path = parsed.path
            payload = self._body()
            if path == "/api/login":
                result = self.service.login(str(payload.get("username", "")), str(payload.get("password", "")))
                if not result:
                    self._error(HTTPStatus.UNAUTHORIZED, "invalid_credentials", "invalid username or password")
                else:
                    self._json(200, result)
                return
            user = self._user()
            actor = user["username"]
            if path == "/api/capsules":
                self._user("capsule_write")
                body = payload.get("payload", payload)
                result = self.service.save_capsule(body, actor, payload.get("expected_revision") if isinstance(payload, dict) else None)
                self._json(200, result)
            elif path == "/api/runs":
                self._user("run")
                result = self.service.run_capsule(
                    str(payload.get("capsule_id", "")), actor,
                    adapter_name=str(payload.get("adapter", "mock")), seed=int(payload.get("seed", 20260721)),
                    allow_network=bool(payload.get("allow_network", False)), endpoint=payload.get("endpoint"), model=payload.get("model"),
                )
                self._json(201, result)
            elif path == "/api/challenges":
                self._user("challenge")
                result = self.service.create_challenge(str(payload.get("run_id", "")), str(payload.get("claim_id", "")), str(payload.get("title", "")), payload.get("protocol", {}), actor)
                self._json(201, result)
            elif path.startswith("/api/challenges/") and path.endswith("/resolve"):
                self._user("challenge")
                challenge_id = path.split("/")[3]
                result = self.service.resolve_challenge(challenge_id, str(payload.get("status", "")), payload.get("resolution", {}), actor)
                self._json(200, result)
            elif path == "/api/export":
                self._user("export")
                self._json(200, self.service.export(str(payload.get("run_id", "")), actor))
            elif path == "/api/import":
                self._user("import")
                bundle = payload.get("bundle", payload)
                self._json(201, self.service.import_external_bundle(bundle, actor))
            elif path == "/api/bundle/verify":
                self._user("read")
                bundle = payload.get("bundle", payload)
                self._json(200, self.service.verify_external_bundle(bundle))
            elif path == "/api/nodes":
                self._user("node_write")
                self._json(200, self.service.save_node(payload, actor))
            else:
                self._error(404, "not_found", "API route not found")
        except Exception as exc:
            self._dispatch_error(exc)

    def _serve_static(self, path: str) -> None:
        web_root: Path = self.server.web_root  # type: ignore[attr-defined]
        rel = "index.html" if path in {"", "/"} else path.lstrip("/")
        target = (web_root / rel).resolve()
        if web_root.resolve() not in target.parents and target != web_root.resolve():
            self._error(403, "forbidden", "invalid static path")
            return
        if not target.is_file():
            self._error(404, "not_found", "static file not found")
            return
        raw = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
            content_type += "; charset=utf-8"
        self._headers(200, content_type, len(raw))
        self.wfile.write(raw)


def serve(service: Service, host: str, port: int) -> None:
    server = WAEGHTTPServer((host, port), Handler, service)
    print(f"DIKWP-Mesh 4.1 WorldAI Evidence Grid v1.0.0")
    print(f"Serving on http://{host}:{port}")
    print("Demo accounts use password: mesh41-demo")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
