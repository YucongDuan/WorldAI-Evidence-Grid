from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .db import Database
from .util import canonical_json, sha256_text, utc_now
from .validation import validate_capsule, validate_node


def seed_project(db: Database, project_root: str | Path) -> dict[str, int]:
    root = Path(project_root)
    counts = {"portfolio": 0, "capsules": 0, "nodes": 0}
    portfolio = json.loads((root / "data" / "portfolio_snapshot.json").read_text(encoding="utf-8"))
    with db.transaction() as conn:
        for item in portfolio["projects"]:
            cursor = conn.execute(
                """INSERT OR IGNORE INTO portfolio_projects(
                    id,repo_name,cluster,claimed_capability,source_state,source_url,integration_slots_json,evidence_state,observed_at,notes
                ) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    item["id"], item["repo_name"], item["cluster"], item["claimed_capability"], item["source_state"],
                    item["source_url"], canonical_json(item["integration_slots"]), item["evidence_state"], item["observed_at"], item["notes"],
                ),
            )
            counts["portfolio"] += max(cursor.rowcount, 0)
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('portfolio_observed_total',?)", (str(portfolio["observed_repository_total"]),))
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('portfolio_curated_count',?)", (str(portfolio["curated_project_count"]),))
        if counts["portfolio"]:
            db.append_audit(conn, "system", "seed_portfolio_snapshot", "portfolio", portfolio["snapshot_id"], {"inserted": counts["portfolio"], "observed_total": portfolio["observed_repository_total"]})

    for path in sorted((root / "data" / "nodes").glob("*.json")):
        node = validate_node(json.loads(path.read_text(encoding="utf-8")))
        with db.transaction() as conn:
            cursor = conn.execute(
                """INSERT OR IGNORE INTO nodes(
                    id,name,jurisdiction,operator,languages_json,data_residency_json,capabilities_json,trust_state,attestation_mode,shared_secret,source_state,created_at,updated_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    node["id"], node["name"], node["jurisdiction"], node["operator"], canonical_json(node["languages"]),
                    canonical_json(node["data_residency"]), canonical_json(node["capabilities"]), node["trust_state"],
                    node["attestation_mode"], node.get("shared_secret"), node["source_state"], utc_now(), utc_now(),
                ),
            )
            inserted = max(cursor.rowcount, 0)
            counts["nodes"] += inserted
            if inserted:
                db.append_audit(conn, "system", "seed_node", "node", node["id"], {"source": path.name})
    with db.transaction() as conn:
        conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES ('local_node_id','node_cn_shanghai_demo')")

    for path in sorted((root / "data" / "capsules").glob("*.json")):
        capsule = validate_capsule(json.loads(path.read_text(encoding="utf-8")))
        payload_json = canonical_json(capsule)
        with db.transaction() as conn:
            now = utc_now()
            cursor = conn.execute(
                """INSERT OR IGNORE INTO capsules(id,title,status,owner,revision,payload_json,payload_hash,created_at,updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (capsule["id"], capsule["title"], capsule["status"], capsule["owner"], 1, payload_json, sha256_text(payload_json), now, now),
            )
            inserted = max(cursor.rowcount, 0)
            counts["capsules"] += inserted
            if inserted:
                db.append_audit(conn, "system", "seed_capsule", "capsule", capsule["id"], {"source": path.name, "revision": 1})
    return counts
