from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .constants import DEFAULT_DB, DEFAULT_HOST, DEFAULT_PORT
from .server import serve
from .service import Service
from .util import atomic_write_json


def project_root() -> Path:
    return Path(__file__).resolve().parent.parent


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DIKWP-Mesh 4.1 WorldAI Evidence Grid")
    parser.add_argument("--db", default=DEFAULT_DB, help="SQLite path; relative paths are resolved inside the project directory")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init", help="initialize and seed the local node")
    pserve = sub.add_parser("serve", help="start the local browser/API server")
    pserve.add_argument("--host", default=DEFAULT_HOST)
    pserve.add_argument("--port", type=int, default=DEFAULT_PORT)

    sub.add_parser("list-capsules", help="list experiment capsules")
    prun = sub.add_parser("run", help="execute a capsule")
    prun.add_argument("--capsule", required=True)
    prun.add_argument("--adapter", default="mock", choices=["mock", "replay", "openai_compatible", "ollama"])
    prun.add_argument("--seed", type=int, default=20260721)
    prun.add_argument("--model")
    prun.add_argument("--endpoint")
    prun.add_argument("--allow-network", action="store_true")
    prun.add_argument("--out")

    pshow = sub.add_parser("show-run", help="print a run record")
    pshow.add_argument("--run", required=True)
    pcompare = sub.add_parser("compare", help="field-level comparison of two runs")
    pcompare.add_argument("--left", required=True)
    pcompare.add_argument("--right", required=True)
    pcompare.add_argument("--out")

    pexport = sub.add_parser("export", help="export a redacted evidence bundle")
    pexport.add_argument("--run", required=True)
    pexport.add_argument("--out", required=True)
    pimport = sub.add_parser("import", help="import an external evidence bundle")
    pimport.add_argument("--file", required=True)

    sub.add_parser("verify-audit", help="verify the local hash-linked audit chain")
    sub.add_parser("summary", help="print local counts and health")
    pqa = sub.add_parser("qa", help="run the packaged automated QA suite")
    pqa.add_argument("--out", default="outputs/qa_summary.json")
    return parser


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def _print(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2))


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = project_root()
    db_path = _resolve(root, args.db)
    service = Service(root, db_path)
    service.initialize()
    try:
        if args.command == "init":
            _print(service.health())
        elif args.command == "serve":
            serve(service, args.host, args.port)
        elif args.command == "list-capsules":
            _print({"capsules": service.list_capsules()})
        elif args.command == "run":
            result = service.run_capsule(
                args.capsule,
                "admin",
                adapter_name=args.adapter,
                seed=args.seed,
                allow_network=args.allow_network,
                endpoint=args.endpoint,
                model=args.model,
            )
            if args.out:
                atomic_write_json(_resolve(root, args.out), result)
            _print({"run_id": result["id"], "statuses": result["evaluation"]["statuses"], "mesh_examination": result["mesh"]["mesh_examination"], "output_hash": result["output_hash"]})
        elif args.command == "show-run":
            _print(service.get_run(args.run))
        elif args.command == "compare":
            result = service.compare_runs(args.left, args.right)
            if args.out:
                atomic_write_json(_resolve(root, args.out), result)
            _print(result)
        elif args.command == "export":
            bundle = service.export(args.run, "admin")
            out = _resolve(root, args.out)
            atomic_write_json(out, bundle)
            _print({"bundle_id": bundle["bundle_id"], "manifest_hash": bundle["manifest_hash"], "out": str(out)})
        elif args.command == "import":
            bundle = json.loads(_resolve(root, args.file).read_text(encoding="utf-8"))
            _print(service.import_external_bundle(bundle, "admin"))
        elif args.command == "verify-audit":
            result = service.db.verify_audit()
            _print(result)
            return 0 if result["valid"] else 2
        elif args.command == "summary":
            _print(service.health())
        elif args.command == "qa":
            from tests.run_qa import run_all
            out = _resolve(root, args.out)
            result = run_all(root, db_path=root / "outputs" / "qa_runtime.sqlite3")
            atomic_write_json(out, result)
            _print(result)
            return 0 if result["passed"] == result["total"] else 3
        else:
            raise RuntimeError("unreachable command")
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0
