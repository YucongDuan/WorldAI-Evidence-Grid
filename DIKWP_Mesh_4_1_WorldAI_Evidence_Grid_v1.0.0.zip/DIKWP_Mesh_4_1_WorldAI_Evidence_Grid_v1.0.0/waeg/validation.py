from __future__ import annotations

from typing import Any

from .constants import DIKWP_CHANNELS, INTENT_SOURCE_STATES
from .util import sha256_text


class ValidationError(ValueError):
    def __init__(self, message: str, path: str = "$"):
        super().__init__(f"{path}: {message}")
        self.path = path
        self.message = message


def _require_dict(value: Any, path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValidationError("must be an object", path)
    return value


def _require_list(value: Any, path: str) -> list[Any]:
    if not isinstance(value, list):
        raise ValidationError("must be an array", path)
    return value


def _require_text(value: Any, path: str, *, allow_empty: bool = False, max_len: int = 20_000) -> str:
    if not isinstance(value, str):
        raise ValidationError("must be a string", path)
    if not allow_empty and not value.strip():
        raise ValidationError("must not be empty", path)
    if len(value) > max_len:
        raise ValidationError(f"must not exceed {max_len} characters", path)
    return value


def validate_capsule(payload: Any) -> dict[str, Any]:
    obj = _require_dict(payload, "$")
    for key in ("schema_version", "id", "title", "status", "owner", "purpose", "authority", "inputs", "tasks", "mesh", "evaluation", "crosswalk_profiles", "safety"):
        if key not in obj:
            raise ValidationError("required property missing", f"$.{key}")
    _require_text(obj["schema_version"], "$.schema_version", max_len=20)
    _require_text(obj["id"], "$.id", max_len=120)
    _require_text(obj["title"], "$.title", max_len=300)
    _require_text(obj["owner"], "$.owner", max_len=120)

    purpose = _require_dict(obj["purpose"], "$.purpose")
    _require_text(purpose.get("statement"), "$.purpose.statement", max_len=10_000)
    source_state = purpose.get("source_state")
    if source_state not in INTENT_SOURCE_STATES:
        raise ValidationError(f"must be one of {INTENT_SOURCE_STATES}", "$.purpose.source_state")
    for key in ("acceptance_conditions", "forbidden_outcomes"):
        values = _require_list(purpose.get(key), f"$.purpose.{key}")
        for i, value in enumerate(values):
            _require_text(value, f"$.purpose.{key}[{i}]", max_len=1_000)

    authority = _require_dict(obj["authority"], "$.authority")
    for key in ("actor", "jurisdiction", "data_locality", "permission_scope", "human_review_required"):
        if key not in authority:
            raise ValidationError("required property missing", f"$.authority.{key}")
    _require_text(authority["actor"], "$.authority.actor", max_len=120)
    _require_text(authority["jurisdiction"], "$.authority.jurisdiction", max_len=120)
    _require_text(authority["data_locality"], "$.authority.data_locality", max_len=120)
    _require_list(authority["permission_scope"], "$.authority.permission_scope")
    if not isinstance(authority["human_review_required"], bool):
        raise ValidationError("must be boolean", "$.authority.human_review_required")

    inputs = _require_list(obj["inputs"], "$.inputs")
    input_ids: set[str] = set()
    for index, item in enumerate(inputs):
        item = _require_dict(item, f"$.inputs[{index}]")
        for key in ("id", "kind", "content", "sha256", "source", "license", "sensitivity"):
            if key not in item:
                raise ValidationError("required property missing", f"$.inputs[{index}].{key}")
        item_id = _require_text(item["id"], f"$.inputs[{index}].id", max_len=120)
        if item_id in input_ids:
            raise ValidationError("duplicate input id", f"$.inputs[{index}].id")
        input_ids.add(item_id)
        content = _require_text(item["content"], f"$.inputs[{index}].content", allow_empty=True, max_len=100_000)
        digest = _require_text(item["sha256"], f"$.inputs[{index}].sha256", max_len=64)
        if len(digest) != 64 or digest != sha256_text(content):
            raise ValidationError("must equal SHA-256 of content", f"$.inputs[{index}].sha256")
        if item["sensitivity"] not in {"public", "internal", "restricted", "secret"}:
            raise ValidationError("unsupported sensitivity", f"$.inputs[{index}].sensitivity")

    tasks = _require_list(obj["tasks"], "$.tasks")
    if not tasks:
        raise ValidationError("must contain at least one task", "$.tasks")
    task_ids: set[str] = set()
    for index, task in enumerate(tasks):
        task = _require_dict(task, f"$.tasks[{index}]")
        for key in ("id", "prompt", "language", "scenario_mode", "must_preserve", "expected_evidence_refs"):
            if key not in task:
                raise ValidationError("required property missing", f"$.tasks[{index}].{key}")
        tid = _require_text(task["id"], f"$.tasks[{index}].id", max_len=120)
        if tid in task_ids:
            raise ValidationError("duplicate task id", f"$.tasks[{index}].id")
        task_ids.add(tid)
        _require_text(task["prompt"], f"$.tasks[{index}].prompt", max_len=30_000)
        _require_text(task["language"], f"$.tasks[{index}].language", max_len=30)
        _require_text(task["scenario_mode"], f"$.tasks[{index}].scenario_mode", max_len=80)
        anchors = _require_list(task["must_preserve"], f"$.tasks[{index}].must_preserve")
        refs = _require_list(task["expected_evidence_refs"], f"$.tasks[{index}].expected_evidence_refs")
        for j, anchor in enumerate(anchors):
            _require_text(anchor, f"$.tasks[{index}].must_preserve[{j}]", max_len=300)
        for j, ref in enumerate(refs):
            _require_text(ref, f"$.tasks[{index}].expected_evidence_refs[{j}]", max_len=120)
            if ref not in input_ids:
                raise ValidationError("unknown input evidence reference", f"$.tasks[{index}].expected_evidence_refs[{j}]")

    mesh = _require_dict(obj["mesh"], "$.mesh")
    channels = _require_list(mesh.get("active_channels"), "$.mesh.active_channels")
    for i, channel in enumerate(channels):
        if channel not in DIKWP_CHANNELS:
            raise ValidationError("unknown DIKWP channel", f"$.mesh.active_channels[{i}]")
    relations = _require_list(mesh.get("relations", []), "$.mesh.relations")
    for i, relation in enumerate(relations):
        relation = _require_dict(relation, f"$.mesh.relations[{i}]")
        if relation.get("channel") not in DIKWP_CHANNELS:
            raise ValidationError("unknown DIKWP channel", f"$.mesh.relations[{i}].channel")

    evaluation = _require_dict(obj["evaluation"], "$.evaluation")
    checks = _require_list(evaluation.get("checks"), "$.evaluation.checks")
    if not checks:
        raise ValidationError("must contain at least one check", "$.evaluation.checks")
    repeat_count = evaluation.get("repeat_count", 1)
    if not isinstance(repeat_count, int) or not (1 <= repeat_count <= 10):
        raise ValidationError("must be an integer from 1 to 10", "$.evaluation.repeat_count")

    profiles = _require_list(obj["crosswalk_profiles"], "$.crosswalk_profiles")
    for i, profile in enumerate(profiles):
        _require_text(profile, f"$.crosswalk_profiles[{i}]", max_len=120)

    safety = _require_dict(obj["safety"], "$.safety")
    for key in ("network_allowed", "tool_execution_allowed", "allowed_tools", "stop_conditions", "recovery_path"):
        if key not in safety:
            raise ValidationError("required property missing", f"$.safety.{key}")
    if not isinstance(safety["network_allowed"], bool):
        raise ValidationError("must be boolean", "$.safety.network_allowed")
    if not isinstance(safety["tool_execution_allowed"], bool):
        raise ValidationError("must be boolean", "$.safety.tool_execution_allowed")
    _require_list(safety["allowed_tools"], "$.safety.allowed_tools")
    _require_list(safety["stop_conditions"], "$.safety.stop_conditions")
    _require_text(safety["recovery_path"], "$.safety.recovery_path", max_len=1_000)
    return obj


def validate_crosswalk_profile(payload: Any) -> dict[str, Any]:
    obj = _require_dict(payload, "$")
    for key in ("id", "title", "jurisdiction", "source_state", "source_urls", "boundary", "controls"):
        if key not in obj:
            raise ValidationError("required property missing", f"$.{key}")
    _require_text(obj["id"], "$.id", max_len=120)
    _require_text(obj["title"], "$.title", max_len=300)
    controls = _require_list(obj["controls"], "$.controls")
    ids: set[str] = set()
    for i, control in enumerate(controls):
        control = _require_dict(control, f"$.controls[{i}]")
        cid = _require_text(control.get("id"), f"$.controls[{i}].id", max_len=120)
        if cid in ids:
            raise ValidationError("duplicate control id", f"$.controls[{i}].id")
        ids.add(cid)
        _require_text(control.get("title"), f"$.controls[{i}].title", max_len=300)
        reqs = _require_list(control.get("requirements"), f"$.controls[{i}].requirements")
        if not reqs:
            raise ValidationError("must contain evidence requirements", f"$.controls[{i}].requirements")
    return obj


def validate_node(payload: Any) -> dict[str, Any]:
    obj = _require_dict(payload, "$")
    for key in ("id", "name", "jurisdiction", "operator", "languages", "data_residency", "capabilities", "trust_state", "attestation_mode", "source_state"):
        if key not in obj:
            raise ValidationError("required property missing", f"$.{key}")
    for key in ("id", "name", "jurisdiction", "operator", "trust_state", "attestation_mode", "source_state"):
        _require_text(obj[key], f"$.{key}", max_len=300)
    for key in ("languages", "data_residency", "capabilities"):
        _require_list(obj[key], f"$.{key}")
    return obj


def validate_bundle(payload: Any) -> dict[str, Any]:
    obj = _require_dict(payload, "$")
    for key in ("bundle_version", "bundle_id", "source_node", "exported_at", "manifest", "run", "evidence_items", "redaction", "manifest_hash", "attestation"):
        if key not in obj:
            raise ValidationError("required property missing", f"$.{key}")
    _require_text(obj["bundle_id"], "$.bundle_id", max_len=160)
    _require_dict(obj["source_node"], "$.source_node")
    manifest = _require_dict(obj["manifest"], "$.manifest")
    _require_dict(obj["run"], "$.run")
    _require_list(obj["evidence_items"], "$.evidence_items")
    _require_dict(obj["redaction"], "$.redaction")
    _require_text(obj["manifest_hash"], "$.manifest_hash", max_len=64)
    if len(obj["manifest_hash"]) != 64:
        raise ValidationError("must be a 64-character SHA-256 hex digest", "$.manifest_hash")
    if "run_id" not in manifest or "payload_hash" not in manifest:
        raise ValidationError("manifest must contain run_id and payload_hash", "$.manifest")
    return obj
