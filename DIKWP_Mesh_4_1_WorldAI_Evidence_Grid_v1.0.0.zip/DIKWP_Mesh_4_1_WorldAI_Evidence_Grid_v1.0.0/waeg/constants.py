"""Project constants. Labels are project-local operational handles, not universal definitions."""

VERSION = "1.0.0"
SYSTEM_ID = "dikwp-mesh-4.1-worldai-evidence-grid"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8810
DEFAULT_DB = "data/waeg.sqlite3"

DIKWP_ROLES = ("D", "I", "K", "W", "P")
DIKWP_CHANNELS = tuple(f"{a}→{b}" for a in DIKWP_ROLES for b in DIKWP_ROLES)

INTENT_SOURCE_STATES = (
    "explicit",
    "user_stipulated",
    "context_inferred",
    "contested",
    "absent",
)

EVIDENCE_RELIABILITY = (
    "Solid",
    "Supported",
    "Provisional",
    "Borrowed",
    "Hollow",
    "Contested",
    "Blocked",
)

SEMANTIC_STABILITY = ("S4", "S3", "S2", "S1", "S0")
MESH_EXAMINATION = ("M4", "M3", "M2", "M1", "M0")
GATE_STATES = ("ALLOW", "REVIEW", "HOLD", "BLOCK", "KILL")
CONTROL_STATES = ("observed", "partial", "missing", "not_applicable", "contested")

ROLES = {
    "admin": {"*"},
    "experiment_designer": {"read", "capsule_write", "run", "challenge", "export"},
    "evaluator": {"read", "run", "challenge", "export"},
    "replicator": {"read", "run", "challenge", "import", "export"},
    "policy_analyst": {"read", "crosswalk", "export"},
    "node_operator": {"read", "run", "import", "export", "node_write"},
    "auditor": {"read", "audit", "export"},
    "public_observer": {"read_public"},
}

DEMO_USERS = (
    ("admin", "系统管理员", "admin"),
    ("designer", "实验设计角色", "experiment_designer"),
    ("evaluator", "评测角色", "evaluator"),
    ("replicator", "独立复现角色", "replicator"),
    ("policy", "政策映射角色", "policy_analyst"),
    ("node", "节点运行角色", "node_operator"),
    ("auditor", "审计角色", "auditor"),
    ("observer", "公共观察角色", "public_observer"),
)

DEFAULT_DEMO_PASSWORD = "mesh41-demo"
