from __future__ import annotations

import hashlib
import hmac
import json
import platform
import sys
import time
from pathlib import Path
from typing import Any

from .adapters import AdapterContext, adapter_catalog, create_adapter
from .crosswalk import CrosswalkRegistry
from .db import Database, decode_json_fields
from .evaluation import derive_statuses, evaluate_run
from .federation import export_bundle, import_bundle, verify_bundle
from .mesh import build_mesh, counterfactual_kernel
from .seed import seed_project
from .util import canonical_json, make_id, sha256_text, utc_now
from .validation import validate_capsule, validate_node


class ConflictError(RuntimeError):
    pass


class Service:
    def __init__(self, project_root: str | Path, db_path: str | Path):
        self.root = Path(project_root).resolve()
        self.db = Database(db_path)
        self.db.initialize()
        self.crosswalks = CrosswalkRegistry(self.root)

    def initialize(self) -> dict[str, Any]:
        seeded = seed_project(self.db, self.root)
        return {"seeded": seeded, "audit": self.db.verify_audit()}

    def health(self) -> dict[str, Any]:
        meta = {row["key"]: row["value"] for row in self.db.query_all("SELECT key,value FROM meta")}
        return {
            "status": "ok",
            "system": meta.get("system_id"),
            "version": meta.get("version"),
            "database": str(self.db.path),
            "audit": self.db.verify_audit(),
            "counts": self.summary_counts(),
            "runtime_boundary": "No external model or network is used unless a capsule and an operator both explicitly allow it.",
        }

    def summary_counts(self) -> dict[str, int]:
        tables = ["portfolio_projects", "capsules", "runs", "evidence_items", "challenges", "nodes", "imports", "audit_events"]
        result = {}
        with self.db.connect() as conn:
            for table in tables:
                result[table] = int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
        return result

    def login(self, username: str, password: str) -> dict[str, Any] | None:
        return self.db.login(username, password)

    def portfolio(self, cluster: str | None = None, query: str | None = None) -> dict[str, Any]:
        clauses, params = [], []
        if cluster:
            clauses.append("cluster=?")
            params.append(cluster)
        if query:
            clauses.append("(repo_name LIKE ? OR claimed_capability LIKE ?)")
            params.extend([f"%{query}%", f"%{query}%"])
        sql = "SELECT * FROM portfolio_projects"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY cluster,repo_name"
        rows = self.db.query_all(sql, tuple(params))
        for row in rows:
            row["integration_slots"] = json.loads(row.pop("integration_slots_json"))
        meta = {row["key"]: row["value"] for row in self.db.query_all("SELECT key,value FROM meta WHERE key LIKE 'portfolio_%'")}
        clusters = self.db.query_all("SELECT cluster,COUNT(*) AS count FROM portfolio_projects GROUP BY cluster ORDER BY cluster")
        return {
            "observed_repository_total": int(meta.get("portfolio_observed_total", 0)),
            "curated_project_count": int(meta.get("portfolio_curated_count", len(rows))),
            "returned_count": len(rows),
            "clusters": clusters,
            "projects": rows,
            "boundary": "Curated snapshot and multi-label engineering grouping; not a complete mirror, popularity ranking or maturity certification.",
        }

    def list_capsules(self) -> list[dict[str, Any]]:
        rows = self.db.query_all("SELECT id,title,status,owner,revision,payload_hash,created_at,updated_at FROM capsules ORDER BY id")
        return rows

    def get_capsule(self, capsule_id: str) -> dict[str, Any]:
        row = self.db.query_one("SELECT * FROM capsules WHERE id=?", (capsule_id,))
        if not row:
            raise KeyError("capsule not found")
        return {
            "id": row["id"], "title": row["title"], "status": row["status"], "owner": row["owner"],
            "revision": row["revision"], "payload_hash": row["payload_hash"], "created_at": row["created_at"],
            "updated_at": row["updated_at"], "payload": json.loads(row["payload_json"]),
        }

    def save_capsule(self, payload: dict[str, Any], actor: str, expected_revision: int | None = None) -> dict[str, Any]:
        capsule = validate_capsule(payload)
        payload_json = canonical_json(capsule)
        now = utc_now()
        existing = self.db.query_one("SELECT * FROM capsules WHERE id=?", (capsule["id"],))
        with self.db.transaction() as conn:
            if existing:
                if expected_revision is None or expected_revision != existing["revision"]:
                    raise ConflictError(f"capsule revision conflict: expected {expected_revision}, current {existing['revision']}")
                revision = existing["revision"] + 1
                cursor = conn.execute(
                    """UPDATE capsules SET title=?,status=?,owner=?,revision=?,payload_json=?,payload_hash=?,updated_at=?
                       WHERE id=? AND revision=?""",
                    (capsule["title"], capsule["status"], capsule["owner"], revision, payload_json, sha256_text(payload_json), now, capsule["id"], existing["revision"]),
                )
                if cursor.rowcount != 1:
                    raise ConflictError("capsule was modified concurrently")
                action = "update_capsule"
            else:
                revision = 1
                conn.execute(
                    """INSERT INTO capsules(id,title,status,owner,revision,payload_json,payload_hash,created_at,updated_at)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (capsule["id"], capsule["title"], capsule["status"], capsule["owner"], revision, payload_json, sha256_text(payload_json), now, now),
                )
                action = "create_capsule"
            self.db.append_audit(conn, actor, action, "capsule", capsule["id"], {"revision": revision, "payload_hash": sha256_text(payload_json)})
        return self.get_capsule(capsule["id"])

    def _sqlite_version(self) -> str:
        with self.db.connect() as conn:
            return str(conn.execute("SELECT sqlite_version()").fetchone()[0])

    def adapters(self) -> list[dict[str, Any]]:
        return adapter_catalog()

    def list_crosswalks(self) -> list[dict[str, Any]]:
        return self.crosswalks.list()

    def list_nodes(self, include_secret: bool = False) -> list[dict[str, Any]]:
        rows = self.db.query_all("SELECT * FROM nodes ORDER BY id")
        result = []
        for row in rows:
            decoded = decode_json_fields(row, ["languages_json", "data_residency_json", "capabilities_json"])
            if not include_secret:
                decoded.pop("shared_secret", None)
            result.append(decoded)
        return result

    def save_node(self, node: dict[str, Any], actor: str) -> dict[str, Any]:
        node = validate_node(node)
        now = utc_now()
        with self.db.transaction() as conn:
            existing = conn.execute("SELECT id FROM nodes WHERE id=?", (node["id"],)).fetchone()
            if existing:
                conn.execute(
                    """UPDATE nodes SET name=?,jurisdiction=?,operator=?,languages_json=?,data_residency_json=?,capabilities_json=?,trust_state=?,attestation_mode=?,shared_secret=COALESCE(?,shared_secret),source_state=?,updated_at=? WHERE id=?""",
                    (node["name"], node["jurisdiction"], node["operator"], canonical_json(node["languages"]), canonical_json(node["data_residency"]), canonical_json(node["capabilities"]), node["trust_state"], node["attestation_mode"], node.get("shared_secret"), node["source_state"], now, node["id"]),
                )
                action = "update_node"
            else:
                conn.execute(
                    """INSERT INTO nodes(id,name,jurisdiction,operator,languages_json,data_residency_json,capabilities_json,trust_state,attestation_mode,shared_secret,source_state,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (node["id"], node["name"], node["jurisdiction"], node["operator"], canonical_json(node["languages"]), canonical_json(node["data_residency"]), canonical_json(node["capabilities"]), node["trust_state"], node["attestation_mode"], node.get("shared_secret"), node["source_state"], now, now),
                )
                action = "create_node"
            self.db.append_audit(conn, actor, action, "node", node["id"], {"jurisdiction": node["jurisdiction"], "trust_state": node["trust_state"]})
        return next(x for x in self.list_nodes() if x["id"] == node["id"])

    def _local_node(self) -> dict[str, Any]:
        meta = self.db.query_one("SELECT value FROM meta WHERE key='local_node_id'")
        node_id = meta["value"] if meta else "node_cn_shanghai_demo"
        node = self.db.query_one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if not node:
            raise RuntimeError("local node is not configured")
        return node

    def run_capsule(
        self,
        capsule_id: str,
        actor: str,
        *,
        adapter_name: str = "mock",
        seed: int = 20260721,
        allow_network: bool = False,
        endpoint: str | None = None,
        model: str | None = None,
    ) -> dict[str, Any]:
        capsule_record = self.get_capsule(capsule_id)
        capsule = capsule_record["payload"]
        adapter = create_adapter(adapter_name)
        context = AdapterContext(allow_network=allow_network, endpoint=endpoint, model=model)
        local_node = self._local_node()
        input_manifest = [
            {"id": item["id"], "kind": item["kind"], "sha256": item["sha256"], "source": item["source"], "license": item["license"], "sensitivity": item["sensitivity"]}
            for item in capsule.get("inputs", [])
        ]
        started = utc_now()
        wall_start, cpu_start = time.perf_counter(), time.process_time()
        repeat_count = int(capsule.get("evaluation", {}).get("repeat_count", 1))
        repeated_outputs = []
        for _ in range(repeat_count):
            repeated_outputs.append(adapter.run(capsule, seed, context))
        wall_seconds = round(time.perf_counter() - wall_start, 6)
        cpu_seconds = round(time.process_time() - cpu_start, 6)
        output = repeated_outputs[0]
        timing = {"wall_seconds": wall_seconds, "process_cpu_seconds": cpu_seconds, "repeat_count": repeat_count, "energy_measured": False}
        run_id = make_id("run")
        manifest = {
            "run_id": run_id,
            "system_version": "1.0.0",
            "capsule_id": capsule_id,
            "capsule_revision": capsule_record["revision"],
            "capsule_payload_hash": capsule_record["payload_hash"],
            "purpose_hash": sha256_text(capsule["purpose"]["statement"]),
            "purpose_source_state": capsule["purpose"]["source_state"],
            "authority": capsule["authority"],
            "adapter": adapter_name,
            "model_requested": model,
            "endpoint_declared": endpoint is not None,
            "network_operator_flag": bool(allow_network),
            "input_manifest": input_manifest,
            "task_manifest": [{"id": t["id"], "language": t["language"], "prompt_hash": sha256_text(t["prompt"])} for t in capsule["tasks"]],
            "safety": capsule["safety"],
            "runtime": {"python": sys.version.split()[0], "platform": platform.platform(), "implementation": platform.python_implementation()},
            "sbom": [{"component": "Python standard library", "version": sys.version.split()[0]}, {"component": "SQLite", "version": self._sqlite_version()}],
            "started_at": started,
        }
        input_hash = sha256_text(canonical_json(input_manifest))
        output_hash = sha256_text(canonical_json(output))
        evaluation = evaluate_run(capsule, output, repeated_outputs, timing, audit_chain_present=True)
        crosswalk = self.crosswalks.evaluate(capsule.get("crosswalk_profiles", []), evaluation["facts"])
        mesh = build_mesh(capsule, output, evaluation, crosswalk, observer=actor)

        def signature(facts: dict[str, Any]) -> dict[str, Any]:
            statuses = derive_statuses(facts)
            cwalk = self.crosswalks.evaluate(capsule.get("crosswalk_profiles", []), facts)
            profile_states = {p["profile_id"]: p.get("summary", {}) for p in cwalk}
            return {"statuses": statuses, "crosswalk": profile_states}

        kernel = counterfactual_kernel(evaluation["facts"], signature, mesh)
        finished = utc_now()
        attestation_payload = {
            "run_id": run_id, "capsule_id": capsule_id, "input_hash": input_hash, "output_hash": output_hash,
            "gate": evaluation["statuses"]["gate"], "finished_at": finished, "node_id": local_node["id"],
        }
        attestation_hash = sha256_text(canonical_json(attestation_payload))
        secret = local_node.get("shared_secret") or ""
        attestation = {
            "payload": attestation_payload,
            "payload_hash": attestation_hash,
            "mode": local_node["attestation_mode"],
            "value": hmac.new(secret.encode(), attestation_hash.encode(), hashlib.sha256).hexdigest() if secret else None,
            "boundary": "Demo shared-secret integrity record; replace with institutional key management and public-key signatures for production.",
        }
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO runs(
                    id,capsule_id,capsule_revision,adapter,model_ref,status,seed,started_at,finished_at,input_hash,output_hash,
                    manifest_json,output_json,evaluation_json,crosswalk_json,mesh_json,kernel_json,attestation_json,source_node_id,created_by,revision
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    run_id,capsule_id,capsule_record["revision"],adapter_name,output.get("model_ref",model or "unknown"),"completed",seed,started,finished,input_hash,output_hash,
                    canonical_json(manifest),canonical_json(output),canonical_json(evaluation),canonical_json(crosswalk),canonical_json(mesh),canonical_json(kernel),canonical_json(attestation),local_node["id"],actor,1,
                ),
            )
            for task in output.get("tasks", []):
                for claim in task.get("claims", []):
                    refs = claim.get("evidence_refs", []) or [""]
                    for ref in refs:
                        evidence_id = make_id("evidence")
                        valid_ref = ref in {x["id"] for x in capsule.get("inputs", [])}
                        reliability = evaluation["statuses"]["evidence_reliability"]
                        conn.execute(
                            """INSERT INTO evidence_items(id,run_id,claim_id,evidence_type,source_ref,status,reliability,payload_json,created_at)
                               VALUES (?,?,?,?,?,?,?,?,?)""",
                            (evidence_id,run_id,str(claim.get("id","unknown")),"declared_reference",str(ref),"linked" if valid_ref else "missing_or_unknown",reliability,canonical_json({"claim": claim, "valid_source_ref": valid_ref}),finished),
                        )
            self.db.append_audit(conn, actor, "run_capsule", "run", run_id, {"capsule_id": capsule_id, "adapter": adapter_name, "input_hash": input_hash, "output_hash": output_hash, "statuses": evaluation["statuses"]})
        return self.get_run(run_id)

    def list_runs(self, capsule_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 500))
        if capsule_id:
            rows = self.db.query_all("SELECT id,capsule_id,capsule_revision,adapter,model_ref,status,seed,started_at,finished_at,input_hash,output_hash,source_node_id,created_by FROM runs WHERE capsule_id=? ORDER BY started_at DESC LIMIT ?", (capsule_id, limit))
        else:
            rows = self.db.query_all("SELECT id,capsule_id,capsule_revision,adapter,model_ref,status,seed,started_at,finished_at,input_hash,output_hash,source_node_id,created_by FROM runs ORDER BY started_at DESC LIMIT ?", (limit,))
        return rows

    def get_run(self, run_id: str) -> dict[str, Any]:
        row = self.db.query_one("SELECT * FROM runs WHERE id=?", (run_id,))
        if not row:
            raise KeyError("run not found")
        result = dict(row)
        for field in ("manifest_json","output_json","evaluation_json","crosswalk_json","mesh_json","kernel_json","attestation_json"):
            result[field.removesuffix("_json")] = json.loads(result.pop(field) or "null")
        evidence = self.db.query_all("SELECT * FROM evidence_items WHERE run_id=? ORDER BY id", (run_id,))
        for item in evidence:
            item["payload"] = json.loads(item.pop("payload_json"))
        result["evidence_items"] = evidence
        result["challenges"] = self.list_challenges(run_id=run_id)
        return result

    def compare_runs(self, left_id: str, right_id: str) -> dict[str, Any]:
        left, right = self.get_run(left_id), self.get_run(right_id)
        def task_map(run: dict[str, Any]) -> dict[str, Any]:
            return {x.get("task_id"): x for x in (run.get("output") or {}).get("tasks", [])}
        lt, rt = task_map(left), task_map(right)
        task_ids = sorted(set(lt) | set(rt))
        task_diff = []
        for tid in task_ids:
            l, r = lt.get(tid), rt.get(tid)
            if not l or not r:
                task_diff.append({"task_id": tid, "state": "missing_on_one_side", "left_present": bool(l), "right_present": bool(r)})
                continue
            le = sorted({ref for c in l.get("claims", []) for ref in c.get("evidence_refs", [])})
            re = sorted({ref for c in r.get("claims", []) for ref in c.get("evidence_refs", [])})
            task_diff.append({
                "task_id": tid,
                "answer_hash_equal": sha256_text(str(l.get("answer",""))) == sha256_text(str(r.get("answer",""))),
                "purpose_ack_equal": l.get("purpose_ack") == r.get("purpose_ack"),
                "anchors_left": l.get("anchors_emitted", []), "anchors_right": r.get("anchors_emitted", []),
                "evidence_refs_left": le, "evidence_refs_right": re,
                "requested_tools_left": l.get("requested_tools", []), "requested_tools_right": r.get("requested_tools", []),
            })
        return {
            "left": {"id": left_id, "adapter": left["adapter"], "model_ref": left["model_ref"], "statuses": left["evaluation"]["statuses"], "output_hash": left["output_hash"]},
            "right": {"id": right_id, "adapter": right["adapter"], "model_ref": right["model_ref"], "statuses": right["evaluation"]["statuses"], "output_hash": right["output_hash"]},
            "tasks": task_diff,
            "no_scalar_ranking": True,
            "boundary": "Differences are field-level observations. They are not a universal model quality ranking or semantic identity judgment.",
        }

    def create_challenge(self, run_id: str, claim_id: str, title: str, protocol: dict[str, Any], actor: str) -> dict[str, Any]:
        if not self.db.query_one("SELECT id FROM runs WHERE id=?", (run_id,)):
            raise KeyError("run not found")
        challenge_id = make_id("challenge")
        now = utc_now()
        with self.db.transaction() as conn:
            conn.execute(
                "INSERT INTO challenges(id,run_id,claim_id,title,protocol_json,status,created_by,created_at,resolution_json) VALUES (?,?,?,?,?,?,?,?,NULL)",
                (challenge_id,run_id,claim_id,title,canonical_json(protocol),"open",actor,now),
            )
            self.db.append_audit(conn, actor, "create_challenge", "challenge", challenge_id, {"run_id": run_id, "claim_id": claim_id, "protocol": protocol})
        return next(x for x in self.list_challenges(run_id=run_id) if x["id"] == challenge_id)

    def resolve_challenge(self, challenge_id: str, status: str, resolution: dict[str, Any], actor: str) -> dict[str, Any]:
        if status not in {"supported","refuted","inconclusive","withdrawn"}:
            raise ValueError("unsupported challenge resolution status")
        with self.db.transaction() as conn:
            cursor = conn.execute("UPDATE challenges SET status=?,resolution_json=? WHERE id=? AND status='open'", (status, canonical_json(resolution), challenge_id))
            if cursor.rowcount != 1:
                raise ConflictError("challenge is missing or already resolved")
            self.db.append_audit(conn, actor, "resolve_challenge", "challenge", challenge_id, {"status": status, "resolution": resolution})
        return next(x for x in self.list_challenges() if x["id"] == challenge_id)

    def list_challenges(self, run_id: str | None = None) -> list[dict[str, Any]]:
        if run_id:
            rows = self.db.query_all("SELECT * FROM challenges WHERE run_id=? ORDER BY created_at DESC", (run_id,))
        else:
            rows = self.db.query_all("SELECT * FROM challenges ORDER BY created_at DESC")
        for row in rows:
            row["protocol"] = json.loads(row.pop("protocol_json"))
            row["resolution"] = json.loads(row.pop("resolution_json")) if row.get("resolution_json") else None
        return rows

    def export(self, run_id: str, actor: str) -> dict[str, Any]:
        return export_bundle(self.db, run_id, actor)

    def verify_external_bundle(self, bundle: dict[str, Any]) -> dict[str, Any]:
        return verify_bundle(self.db, bundle)

    def import_external_bundle(self, bundle: dict[str, Any], actor: str) -> dict[str, Any]:
        return import_bundle(self.db, bundle, actor)

    def list_imports(self) -> list[dict[str, Any]]:
        rows = self.db.query_all("SELECT id,bundle_id,source_node_id,status,manifest_hash,verification_json,imported_by,created_at FROM imports ORDER BY created_at DESC")
        for row in rows:
            row["verification"] = json.loads(row.pop("verification_json"))
        return rows

    def audit(self, limit: int = 200) -> dict[str, Any]:
        rows = self.db.query_all("SELECT * FROM audit_events ORDER BY seq DESC LIMIT ?", (max(1,min(limit,1000)),))
        return {"verification": self.db.verify_audit(), "events": rows}
