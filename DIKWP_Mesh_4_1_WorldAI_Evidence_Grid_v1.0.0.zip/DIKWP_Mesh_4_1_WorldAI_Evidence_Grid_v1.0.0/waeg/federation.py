from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any

from .db import Database, decode_json_fields
from .util import canonical_json, make_id, sha256_text, utc_now
from .validation import validate_bundle


def _hmac(secret: str, message: str) -> str:
    return hmac.new(secret.encode("utf-8"), message.encode("utf-8"), hashlib.sha256).hexdigest()


def _public_node(row: dict[str, Any]) -> dict[str, Any]:
    decoded = decode_json_fields(row, ["languages_json", "data_residency_json", "capabilities_json"])
    return {
        "id": decoded["id"],
        "name": decoded["name"],
        "jurisdiction": decoded["jurisdiction"],
        "operator": decoded["operator"],
        "languages": decoded.get("languages", []),
        "data_residency": decoded.get("data_residency", []),
        "capabilities": decoded.get("capabilities", []),
        "trust_state": decoded["trust_state"],
        "attestation_mode": decoded["attestation_mode"],
        "source_state": decoded["source_state"],
    }


def export_bundle(db: Database, run_id: str, actor: str, *, include_public_output: bool = True) -> dict[str, Any]:
    run = db.query_one("SELECT * FROM runs WHERE id=?", (run_id,))
    if not run:
        raise KeyError("run not found")
    capsule = db.query_one("SELECT * FROM capsules WHERE id=?", (run["capsule_id"],))
    node = db.query_one("SELECT * FROM nodes WHERE id=?", (run["source_node_id"],))
    if not capsule or not node:
        raise RuntimeError("run references missing capsule or node")
    capsule_payload = json.loads(capsule["payload_json"])
    output = json.loads(run["output_json"] or "{}")
    evaluation = json.loads(run["evaluation_json"] or "{}")
    crosswalk = json.loads(run["crosswalk_json"] or "[]")
    mesh = json.loads(run["mesh_json"] or "{}")
    kernel = json.loads(run["kernel_json"] or "{}")
    evidence = db.query_all("SELECT * FROM evidence_items WHERE run_id=? ORDER BY id", (run_id,))
    evidence_public = []
    for item in evidence:
        evidence_public.append({
            "id": item["id"], "claim_id": item["claim_id"], "evidence_type": item["evidence_type"],
            "source_ref": item["source_ref"], "status": item["status"], "reliability": item["reliability"],
            "payload": json.loads(item["payload_json"]), "created_at": item["created_at"],
        })
    restricted = [item["id"] for item in capsule_payload.get("inputs", []) if item.get("sensitivity") in {"restricted", "secret"}]
    output_exported = include_public_output and not restricted
    run_public = {
        "id": run["id"],
        "capsule_id": run["capsule_id"],
        "capsule_revision": run["capsule_revision"],
        "adapter": run["adapter"],
        "model_ref": run["model_ref"],
        "status": run["status"],
        "seed": run["seed"],
        "started_at": run["started_at"],
        "finished_at": run["finished_at"],
        "input_hash": run["input_hash"],
        "output_hash": run["output_hash"],
        "manifest": json.loads(run["manifest_json"]),
        "output": output if output_exported else {"redacted": True, "output_hash": run["output_hash"]},
        "evaluation": evaluation,
        "crosswalk": crosswalk,
        "mesh": mesh,
        "kernel": kernel,
        "attestation": json.loads(run["attestation_json"] or "{}"),
    }
    redaction = {
        "raw_input_content_exported": False,
        "output_exported": output_exported,
        "restricted_input_ids": restricted,
        "policy": "Raw capsule inputs are never exported. Output is withheld when restricted/secret inputs are present.",
    }
    payload = {
        "source_node": _public_node(node),
        "run": run_public,
        "evidence_items": evidence_public,
        "redaction": redaction,
    }
    payload_hash = sha256_text(canonical_json(payload))
    manifest = {
        "run_id": run_id,
        "capsule_id": run["capsule_id"],
        "source_node_id": node["id"],
        "payload_hash": payload_hash,
        "evidence_item_count": len(evidence_public),
        "schema_version": "1.0",
    }
    manifest_hash = sha256_text(canonical_json(manifest))
    secret = node.get("shared_secret") or ""
    attestation = {
        "mode": node["attestation_mode"],
        "key_id": node["id"] + ":demo-shared-secret",
        "value": _hmac(secret, manifest_hash) if secret else None,
        "boundary": "HMAC confirms possession of a configured shared secret only; it is not public-key identity proof or non-repudiation.",
    }
    bundle = {
        "bundle_version": "1.0",
        "bundle_id": make_id("bundle"),
        "source_node": payload["source_node"],
        "exported_at": utc_now(),
        "manifest": manifest,
        "run": payload["run"],
        "evidence_items": payload["evidence_items"],
        "redaction": payload["redaction"],
        "manifest_hash": manifest_hash,
        "attestation": attestation,
    }
    validate_bundle(bundle)
    with db.transaction() as conn:
        db.append_audit(conn, actor, "export_evidence_bundle", "run", run_id, {"bundle_id": bundle["bundle_id"], "manifest_hash": manifest_hash, "redaction": redaction})
    return bundle


def verify_bundle(db: Database, bundle: dict[str, Any]) -> dict[str, Any]:
    validate_bundle(bundle)
    payload = {
        "source_node": bundle["source_node"],
        "run": bundle["run"],
        "evidence_items": bundle["evidence_items"],
        "redaction": bundle["redaction"],
    }
    payload_hash = sha256_text(canonical_json(payload))
    manifest_expected = dict(bundle["manifest"])
    payload_match = payload_hash == manifest_expected.get("payload_hash")
    manifest_hash = sha256_text(canonical_json(manifest_expected))
    manifest_match = manifest_hash == bundle["manifest_hash"]
    node_id = str(bundle["source_node"].get("id", ""))
    node = db.query_one("SELECT * FROM nodes WHERE id=?", (node_id,))
    attestation_state = "unverified_unknown_peer"
    attestation_match: bool | None = None
    if node and node.get("shared_secret") and bundle.get("attestation", {}).get("value"):
        expected = _hmac(node["shared_secret"], manifest_hash)
        attestation_match = hmac.compare_digest(expected, bundle["attestation"]["value"])
        attestation_state = "verified_shared_secret" if attestation_match else "failed_shared_secret"
    structural_valid = payload_match and manifest_match
    return {
        "structural_valid": structural_valid,
        "payload_hash_match": payload_match,
        "manifest_hash_match": manifest_match,
        "attestation_state": attestation_state,
        "attestation_match": attestation_match,
        "source_node_known": bool(node),
        "authority_inherited": False,
        "boundary": "Imported evidence remains external and non-authoritative until local human and institutional review, regardless of hash or HMAC status.",
    }


def import_bundle(db: Database, bundle: dict[str, Any], actor: str) -> dict[str, Any]:
    verification = verify_bundle(db, bundle)
    status = "accepted_external_evidence" if verification["structural_valid"] else "rejected_invalid_structure"
    import_id = make_id("import")
    with db.transaction() as conn:
        conn.execute(
            """INSERT INTO imports(id,bundle_id,source_node_id,status,manifest_hash,verification_json,payload_json,imported_by,created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (
                import_id, bundle["bundle_id"], str(bundle["source_node"].get("id", "unknown")), status,
                bundle["manifest_hash"], canonical_json(verification), canonical_json(bundle), actor, utc_now(),
            ),
        )
        db.append_audit(conn, actor, "import_evidence_bundle", "import", import_id, {"bundle_id": bundle["bundle_id"], "status": status, "verification": verification})
    return {"import_id": import_id, "status": status, "verification": verification}
