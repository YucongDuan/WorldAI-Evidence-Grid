from __future__ import annotations

import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

from .constants import ROLES

PBKDF2_ITERATIONS = 210_000


def hash_password(password: str, salt_hex: str | None = None) -> tuple[str, str]:
    if not password or len(password) < 8:
        raise ValueError("password must contain at least 8 characters")
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return salt.hex(), digest.hex()


def verify_password(password: str, salt_hex: str, digest_hex: str) -> bool:
    try:
        _, candidate = hash_password(password, salt_hex)
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(candidate, digest_hex)


def issue_token() -> str:
    return secrets.token_urlsafe(32)


def expiry(hours: int = 12) -> str:
    return (datetime.now(timezone.utc) + timedelta(hours=hours)).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def expired(expires_at: str) -> bool:
    try:
        parsed = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
    except ValueError:
        return True
    return parsed <= datetime.now(timezone.utc)


def can(role: str, permission: str) -> bool:
    permissions = ROLES.get(role, set())
    return "*" in permissions or permission in permissions or (permission == "read" and "read_public" in permissions)


def public_user() -> dict[str, Any]:
    return {"username": "anonymous", "display_name": "匿名观察者", "role": "public_observer"}
