from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from .auth import expiry, hash_password, issue_token, verify_password, expired
from .constants import DEFAULT_DEMO_PASSWORD, DEMO_USERS, SYSTEM_ID, VERSION
from .util import canonical_json, make_id, sha256_text, utc_now



class ClosingConnection(sqlite3.Connection):
    """sqlite3 context manager that also closes the connection on exit."""

    def __exit__(self, exc_type, exc_value, traceback):  # type: ignore[no-untyped-def]
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL,
    salt TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    username TEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS nodes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    jurisdiction TEXT NOT NULL,
    operator TEXT NOT NULL,
    languages_json TEXT NOT NULL,
    data_residency_json TEXT NOT NULL,
    capabilities_json TEXT NOT NULL,
    trust_state TEXT NOT NULL,
    attestation_mode TEXT NOT NULL,
    shared_secret TEXT,
    source_state TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS portfolio_projects (
    id TEXT PRIMARY KEY,
    repo_name TEXT NOT NULL UNIQUE,
    cluster TEXT NOT NULL,
    claimed_capability TEXT NOT NULL,
    source_state TEXT NOT NULL,
    source_url TEXT NOT NULL,
    integration_slots_json TEXT NOT NULL,
    evidence_state TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS capsules (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    status TEXT NOT NULL,
    owner TEXT NOT NULL,
    revision INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY,
    capsule_id TEXT NOT NULL REFERENCES capsules(id),
    capsule_revision INTEGER NOT NULL,
    adapter TEXT NOT NULL,
    model_ref TEXT NOT NULL,
    status TEXT NOT NULL,
    seed INTEGER NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    input_hash TEXT NOT NULL,
    output_hash TEXT,
    manifest_json TEXT NOT NULL,
    output_json TEXT,
    evaluation_json TEXT,
    crosswalk_json TEXT,
    mesh_json TEXT,
    kernel_json TEXT,
    attestation_json TEXT,
    source_node_id TEXT REFERENCES nodes(id),
    created_by TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS evidence_items (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    claim_id TEXT NOT NULL,
    evidence_type TEXT NOT NULL,
    source_ref TEXT NOT NULL,
    status TEXT NOT NULL,
    reliability TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS challenges (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES runs(id),
    claim_id TEXT NOT NULL,
    title TEXT NOT NULL,
    protocol_json TEXT NOT NULL,
    status TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    resolution_json TEXT
);

CREATE TABLE IF NOT EXISTS imports (
    id TEXT PRIMARY KEY,
    bundle_id TEXT NOT NULL,
    source_node_id TEXT NOT NULL,
    status TEXT NOT NULL,
    manifest_hash TEXT NOT NULL,
    verification_json TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    imported_by TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_events (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL UNIQUE,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    object_type TEXT NOT NULL,
    object_id TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    prev_hash TEXT NOT NULL,
    event_hash TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_runs_capsule ON runs(capsule_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_evidence_run ON evidence_items(run_id);
CREATE INDEX IF NOT EXISTS idx_challenges_run ON challenges(run_id, status);
CREATE INDEX IF NOT EXISTS idx_audit_object ON audit_events(object_type, object_id, seq);
CREATE INDEX IF NOT EXISTS idx_portfolio_cluster ON portfolio_projects(cluster, repo_name);
"""


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=30, isolation_level=None, factory=ClosingConnection)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def initialize(self) -> None:
        with self._lock, self.connect() as conn:
            conn.executescript(SCHEMA)
            now = utc_now()
            values = {
                "system_id": SYSTEM_ID,
                "version": VERSION,
                "created_at": now,
                "schema_version": "1",
            }
            for key, value in values.items():
                conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES (?,?)", (key, value))
            self._seed_users(conn)

    def _seed_users(self, conn: sqlite3.Connection) -> None:
        count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if count:
            return
        now = utc_now()
        for username, display_name, role in DEMO_USERS:
            salt, digest = hash_password(DEFAULT_DEMO_PASSWORD)
            conn.execute(
                "INSERT INTO users(username,display_name,role,salt,password_hash,active,created_at) VALUES (?,?,?,?,?,?,?)",
                (username, display_name, role, salt, digest, 1, now),
            )
        self.append_audit(conn, "system", "seed_demo_users", "system", SYSTEM_ID, {"user_count": len(DEMO_USERS)})

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            conn = self.connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                yield conn
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            finally:
                conn.close()

    def query_all(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        with self.connect() as conn:
            return [dict(row) for row in conn.execute(sql, params).fetchall()]

    def query_one(self, sql: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute(sql, params).fetchone()
            return dict(row) if row else None

    def append_audit(
        self,
        conn: sqlite3.Connection,
        actor: str,
        action: str,
        object_type: str,
        object_id: str,
        payload: Any,
    ) -> dict[str, Any]:
        last = conn.execute("SELECT event_hash FROM audit_events ORDER BY seq DESC LIMIT 1").fetchone()
        prev_hash = last[0] if last else "0" * 64
        event = {
            "event_id": make_id("audit"),
            "actor": actor,
            "action": action,
            "object_type": object_type,
            "object_id": object_id,
            "payload_hash": sha256_text(canonical_json(payload)),
            "prev_hash": prev_hash,
            "created_at": utc_now(),
        }
        event_hash = sha256_text(canonical_json(event))
        conn.execute(
            """INSERT INTO audit_events(event_id,actor,action,object_type,object_id,payload_hash,prev_hash,event_hash,created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (
                event["event_id"], event["actor"], event["action"], event["object_type"], event["object_id"],
                event["payload_hash"], event["prev_hash"], event_hash, event["created_at"],
            ),
        )
        event["event_hash"] = event_hash
        return event

    def verify_audit(self) -> dict[str, Any]:
        rows = self.query_all("SELECT * FROM audit_events ORDER BY seq")
        expected_prev = "0" * 64
        failures: list[dict[str, Any]] = []
        for row in rows:
            event = {
                "event_id": row["event_id"],
                "actor": row["actor"],
                "action": row["action"],
                "object_type": row["object_type"],
                "object_id": row["object_id"],
                "payload_hash": row["payload_hash"],
                "prev_hash": row["prev_hash"],
                "created_at": row["created_at"],
            }
            calculated = sha256_text(canonical_json(event))
            if row["prev_hash"] != expected_prev or calculated != row["event_hash"]:
                failures.append({
                    "seq": row["seq"],
                    "prev_expected": expected_prev,
                    "prev_actual": row["prev_hash"],
                    "hash_expected": calculated,
                    "hash_actual": row["event_hash"],
                })
            expected_prev = row["event_hash"]
        return {
            "valid": not failures,
            "event_count": len(rows),
            "head_hash": expected_prev,
            "failures": failures,
        }

    def login(self, username: str, password: str) -> dict[str, Any] | None:
        with self.transaction() as conn:
            row = conn.execute("SELECT * FROM users WHERE username=? AND active=1", (username,)).fetchone()
            if not row or not verify_password(password, row["salt"], row["password_hash"]):
                return None
            token = issue_token()
            exp = expiry()
            now = utc_now()
            conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (now,))
            conn.execute("INSERT INTO sessions(token,username,expires_at,created_at) VALUES (?,?,?,?)", (token, username, exp, now))
            self.append_audit(conn, username, "login", "session", token[:12], {"expires_at": exp})
            return {
                "token": token,
                "expires_at": exp,
                "user": {"username": row["username"], "display_name": row["display_name"], "role": row["role"]},
            }

    def user_for_token(self, token: str) -> dict[str, Any] | None:
        if not token:
            return None
        row = self.query_one(
            """SELECT u.username,u.display_name,u.role,s.expires_at
               FROM sessions s JOIN users u ON u.username=s.username
               WHERE s.token=? AND u.active=1""",
            (token,),
        )
        if not row or expired(row["expires_at"]):
            return None
        return {"username": row["username"], "display_name": row["display_name"], "role": row["role"]}


def decode_json_fields(row: dict[str, Any], fields: list[str]) -> dict[str, Any]:
    result = dict(row)
    for field in fields:
        value = result.get(field)
        if value is not None and isinstance(value, str):
            try:
                result[field.removesuffix("_json")] = json.loads(value)
            except json.JSONDecodeError:
                result[field.removesuffix("_json")] = None
    return result
