from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .validation import validate_crosswalk_profile


class CrosswalkRegistry:
    def __init__(self, project_root: str | Path):
        self.root = Path(project_root)
        self._profiles: dict[str, dict[str, Any]] = {}
        self.reload()

    def reload(self) -> None:
        profiles: dict[str, dict[str, Any]] = {}
        for path in sorted((self.root / "data" / "crosswalk_profiles").glob("*.json")):
            profile = validate_crosswalk_profile(json.loads(path.read_text(encoding="utf-8")))
            profiles[profile["id"]] = profile
        self._profiles = profiles

    def list(self) -> list[dict[str, Any]]:
        return [self._profiles[key] for key in sorted(self._profiles)]

    def get(self, profile_id: str) -> dict[str, Any] | None:
        return self._profiles.get(profile_id)

    def evaluate(self, profile_ids: list[str], facts: dict[str, Any]) -> list[dict[str, Any]]:
        results = []
        for profile_id in profile_ids:
            profile = self._profiles.get(profile_id)
            if not profile:
                results.append({"profile_id": profile_id, "status": "missing_profile", "controls": [], "boundary": "Profile was not found locally."})
                continue
            controls = []
            summary = {"observed": 0, "partial": 0, "missing": 0, "not_applicable": 0, "contested": 0}
            for control in profile["controls"]:
                requirements = control["requirements"]
                observed = [key for key in requirements if bool(facts.get(key))]
                absent = [key for key in requirements if not bool(facts.get(key))]
                if observed and not absent:
                    state = "observed"
                elif observed:
                    state = "partial"
                else:
                    state = "missing"
                summary[state] += 1
                controls.append({
                    "control_id": control["id"],
                    "title": control["title"],
                    "state": state,
                    "observed_evidence_fields": observed,
                    "missing_evidence_fields": absent,
                })
            results.append({
                "profile_id": profile["id"],
                "title": profile["title"],
                "jurisdiction": profile["jurisdiction"],
                "source_state": profile["source_state"],
                "source_urls": profile["source_urls"],
                "boundary": profile["boundary"],
                "summary": summary,
                "controls": controls,
                "no_scalar_without_weights": True,
                "conformity_claim": False,
            })
        return results
