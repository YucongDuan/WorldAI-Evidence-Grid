'use strict';

const state = {
  token: localStorage.getItem('waeg_token') || '',
  user: null,
  health: null,
  portfolio: null,
  capsules: [],
  runs: [],
  profiles: [],
  nodes: [],
  challenges: [],
  imports: [],
  selectedRun: null,
  selectedCapsule: null,
};

const $ = (id) => document.getElementById(id);
const esc = (value) => String(value ?? '')
  .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;').replaceAll("'", '&#039;');
const pretty = (value) => JSON.stringify(value, null, 2);
const short = (value, length = 16) => {
  const text = String(value ?? '');
  return text.length > length ? `${text.slice(0, length)}…` : text;
};
const badgeClass = (value) => {
  const good = new Set(['ok', 'valid', 'ALLOW', 'S4', 'M4', 'Supported', 'Solid', 'observed', 'completed', 'accepted_external_evidence']);
  const bad = new Set(['KILL', 'BLOCK', 'S0', 'M0', 'Blocked', 'Hollow', 'failed', 'missing', 'rejected_invalid_structure']);
  return good.has(value) ? 'good' : bad.has(value) ? 'bad' : 'warn';
};

function toast(message, bad = false) {
  const el = $('toast');
  el.textContent = message;
  el.classList.remove('hidden', 'bad');
  if (bad) el.classList.add('bad');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.add('hidden'), 4200);
}

async function api(path, options = {}) {
  const headers = {'Content-Type': 'application/json', ...(options.headers || {})};
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const response = await fetch(path, {...options, headers});
  let payload = null;
  try { payload = await response.json(); } catch { payload = {error: {message: `HTTP ${response.status}`}}; }
  if (!response.ok) {
    const message = payload?.error?.message || `HTTP ${response.status}`;
    if (response.status === 401 || response.status === 403) {
      if (message.includes('authentication')) signOut(false);
    }
    throw new Error(message);
  }
  return payload;
}

async function checkHealth() {
  try {
    state.health = await api('/api/health', {headers: {Authorization: ''}});
    $('healthBadge').textContent = `节点 ${state.health.status}`;
    $('healthBadge').className = `badge ${state.health.status === 'ok' ? 'good' : 'warn'}`;
  } catch (error) {
    $('healthBadge').textContent = '节点不可达';
    $('healthBadge').className = 'badge bad';
  }
}

function setSignedIn(user) {
  state.user = user;
  $('loginView').classList.add('hidden');
  $('workspace').classList.remove('hidden');
  $('nav').classList.remove('hidden');
  $('logoutBtn').classList.remove('hidden');
  $('userBadge').textContent = `${user.display_name} · ${user.role}`;
  $('userBadge').className = 'badge good';
}

function signOut(show = true) {
  state.token = '';
  state.user = null;
  localStorage.removeItem('waeg_token');
  $('loginView').classList.remove('hidden');
  $('workspace').classList.add('hidden');
  $('nav').classList.add('hidden');
  $('logoutBtn').classList.add('hidden');
  $('userBadge').textContent = '未登录';
  $('userBadge').className = 'badge neutral';
  if (show) toast('已退出本地工作区');
}

async function restoreSession() {
  if (!state.token) return;
  try {
    const user = await api('/api/me');
    setSignedIn(user);
    await loadWorkspace();
  } catch {
    signOut(false);
  }
}

async function loadWorkspace() {
  await Promise.allSettled([
    loadOverview(), loadPortfolio(), loadCapsules(), loadRuns(), loadProfiles(),
    loadNodes(), loadChallenges(), loadImports(), loadAudit(),
  ]);
}

function metric(label, value, note = '') {
  return `<div class="metric-card"><div class="value">${esc(value)}</div><div class="label">${esc(label)}</div>${note ? `<div class="hint">${esc(note)}</div>` : ''}</div>`;
}

async function loadOverview() {
  const [summary, portfolio] = await Promise.all([api('/api/summary'), api('/api/portfolio')]);
  state.portfolio = portfolio;
  const counts = summary.counts;
  $('overviewCards').innerHTML = [
    metric('公开账户观察仓库数', portfolio.observed_repository_total, 'GitHub页面时点快照'),
    metric('本地策展项目记录', portfolio.curated_project_count, '非完整镜像、非成熟度排名'),
    metric('可运行实验胶囊', counts.capsules),
    metric('已生成运行证据', counts.runs),
    metric('联邦节点', counts.nodes),
    metric('证据挑战', counts.challenges),
    metric('审计事件', counts.audit_events, summary.audit.valid ? '哈希链当前有效' : '哈希链存在异常'),
  ].join('');
  const clusterItems = portfolio.clusters
    .map((item) => `<div class="control observed"><strong>${esc(item.cluster)}</strong><div class="hint">${esc(item.count)} 个策展记录</div></div>`)
    .join('');
  $('kernelSummary').innerHTML = clusterItems || '<div class="muted">暂无谱系数据</div>';
}

async function loadPortfolio(cluster = '', query = '') {
  const params = new URLSearchParams();
  if (cluster) params.set('cluster', cluster);
  if (query) params.set('q', query);
  const data = await api(`/api/portfolio${params.toString() ? `?${params}` : ''}`);
  state.portfolio = data;
  const select = $('portfolioCluster');
  const current = cluster || select.value;
  const clusters = data.clusters || [];
  select.innerHTML = '<option value="">全部关系簇</option>' + clusters.map((x) => `<option value="${esc(x.cluster)}">${esc(x.cluster)} (${x.count})</option>`).join('');
  select.value = current;
  $('portfolioMeta').textContent = `账户页面观察到 ${data.observed_repository_total} 个公开仓库；本地策展 ${data.curated_project_count} 个代表性记录；当前返回 ${data.returned_count} 个。${data.boundary}`;
  $('portfolioTable').innerHTML = data.projects.map((item) => `<tr>
    <td><strong>${esc(item.repo_name)}</strong><div class="hint">${esc(item.source_state)}</div></td>
    <td>${esc(item.cluster)}</td>
    <td>${esc(item.claimed_capability)}<div class="hint">${esc(item.notes)}</div></td>
    <td>${(item.integration_slots || []).map((x) => `<span class="tag">${esc(x)}</span>`).join('')}</td>
    <td>${esc(item.evidence_state)}</td>
  </tr>`).join('');
}

async function loadCapsules() {
  const [capData, adapterData] = await Promise.all([api('/api/capsules'), api('/api/adapters')]);
  state.capsules = capData.capsules || [];
  $('capsuleList').innerHTML = state.capsules.map((item) => `<div class="list-item"><button data-capsule="${esc(item.id)}"><strong>${esc(item.title)}</strong><small>${esc(item.id)} · revision ${item.revision} · ${esc(item.status)}</small></button></div>`).join('');
  document.querySelectorAll('[data-capsule]').forEach((button) => button.addEventListener('click', () => selectCapsule(button.dataset.capsule)));
  const options = state.capsules.map((x) => `<option value="${esc(x.id)}">${esc(x.title)}</option>`).join('');
  $('runCapsule').innerHTML = options;
  $('runAdapter').innerHTML = (adapterData.adapters || []).map((x) => `<option value="${esc(x.id)}">${esc(x.id)} · ${esc(x.description)}</option>`).join('');
  if (state.capsules.length && !state.selectedCapsule) await selectCapsule(state.capsules[0].id);
}

async function selectCapsule(id) {
  const record = await api(`/api/capsules/${encodeURIComponent(id)}`);
  state.selectedCapsule = record;
  $('capsuleDetail').textContent = pretty(record);
  $('capsuleEditor').value = pretty(record.payload);
  $('capsuleRevision').value = record.revision;
  $('runCapsule').value = id;
}

async function saveCapsule() {
  let payload;
  try { payload = JSON.parse($('capsuleEditor').value); }
  catch (error) { throw new Error(`胶囊 JSON 无效：${error.message}`); }
  const revisionText = $('capsuleRevision').value.trim();
  const body = {payload};
  if (revisionText) body.expected_revision = Number(revisionText);
  const record = await api('/api/capsules', {method: 'POST', body: JSON.stringify(body)});
  state.selectedCapsule = record;
  $('capsuleRevision').value = record.revision;
  $('capsuleDetail').textContent = pretty(record);
  await loadCapsules();
  toast(`胶囊已保存：${record.id} revision ${record.revision}`);
}

async function executeCapsule() {
  const body = {
    capsule_id: $('runCapsule').value,
    adapter: $('runAdapter').value,
    seed: Number($('runSeed').value || 20260721),
    allow_network: $('allowNetwork').checked,
  };
  if ($('runModel').value.trim()) body.model = $('runModel').value.trim();
  if ($('runEndpoint').value.trim()) body.endpoint = $('runEndpoint').value.trim();
  const result = await api('/api/runs', {method: 'POST', body: JSON.stringify(body)});
  state.selectedRun = result;
  await loadRuns();
  renderRun(result);
  showView('runs');
  toast(`运行证据已生成：${result.id}`);
}

function populateRunSelects() {
  const options = state.runs.map((r) => `<option value="${esc(r.id)}">${esc(r.id)} · ${esc(r.adapter)}/${esc(r.model_ref)}</option>`).join('');
  ['compareLeft', 'compareRight', 'crosswalkRun', 'exportRun', 'challengeRun', 'meshRun'].forEach((id) => {
    const el = $(id);
    const old = el.value;
    el.innerHTML = options;
    if ([...el.options].some((o) => o.value === old)) el.value = old;
  });
  if (state.runs.length > 1) $('compareRight').selectedIndex = 1;
}

async function loadRuns() {
  const data = await api('/api/runs?limit=200');
  state.runs = data.runs || [];
  $('runsTable').innerHTML = state.runs.map((run) => `<tr class="clickable" data-run="${esc(run.id)}">
    <td><strong>${esc(run.id)}</strong><div class="hint">seed ${run.seed}</div></td>
    <td>${esc(run.capsule_id)}<div class="hint">revision ${run.capsule_revision}</div></td>
    <td>${esc(run.adapter)} / ${esc(run.model_ref)}</td>
    <td>${esc(run.finished_at || run.started_at)}</td>
    <td><code>${esc(short(run.output_hash, 22))}</code></td>
  </tr>`).join('');
  document.querySelectorAll('[data-run]').forEach((row) => row.addEventListener('click', () => selectRun(row.dataset.run)));
  populateRunSelects();
  if (state.runs.length && !state.selectedRun) await selectRun(state.runs[0].id);
}

async function selectRun(id) {
  state.selectedRun = await api(`/api/runs/${encodeURIComponent(id)}`);
  renderRun(state.selectedRun);
  ['crosswalkRun', 'meshRun', 'exportRun', 'challengeRun'].forEach((el) => { if ($(el)) $(el).value = id; });
  renderCrosswalk(state.selectedRun);
  renderMesh(state.selectedRun);
}

function renderRun(run) {
  if (!run) return;
  const statuses = run.evaluation?.statuses || {};
  const meshStatus = run.mesh?.mesh_examination || 'M0';
  $('runStatus').innerHTML = [
    ['Gate', statuses.gate],
    ['Semantic Stability', statuses.semantic_stability],
    ['Mesh Examination', meshStatus],
    ['Evidence Reliability', statuses.evidence_reliability],
  ].map(([label, value]) => `<div class="status-box"><strong class="${badgeClass(value)}">${esc(value)}</strong><span>${esc(label)}</span></div>`).join('');
  const checks = run.evaluation?.checks || {};
  const residuals = run.evaluation?.residuals || [];
  $('runChecks').innerHTML = Object.entries(checks).map(([key, value]) => `<div class="control ${value?.passed === true ? 'observed' : value?.passed === false ? 'missing' : 'partial'}"><strong>${esc(key)}</strong><pre>${esc(pretty(value))}</pre></div>`).join('') +
    `<div class="control partial"><strong>Residuals</strong><div>${residuals.length ? residuals.map((x) => `<span class="tag">${esc(x)}</span>`).join('') : '无已记录残差'}</div></div>`;
  $('runDetail').textContent = pretty(run);
}

async function compareRuns() {
  const left = $('compareLeft').value;
  const right = $('compareRight').value;
  if (!left || !right) throw new Error('请选择左右两条运行记录');
  const data = await api(`/api/compare?left=${encodeURIComponent(left)}&right=${encodeURIComponent(right)}`);
  $('compareSummary').innerHTML = [
    metric('左侧 Gate', data.left.statuses.gate, `${data.left.adapter}/${data.left.model_ref}`),
    metric('右侧 Gate', data.right.statuses.gate, `${data.right.adapter}/${data.right.model_ref}`),
    metric('输出哈希相同', data.left.output_hash === data.right.output_hash ? '是' : '否'),
    metric('任务差异记录', data.tasks.length, '不形成无权重质量排名'),
  ].join('');
  $('compareDetail').textContent = pretty(data);
}

async function loadProfiles() {
  const data = await api('/api/crosswalks');
  state.profiles = data.profiles || [];
  $('profileCards').innerHTML = state.profiles.map((profile) => `<div class="profile-card">
    <div class="eyebrow">${esc(profile.jurisdiction)}</div><h3>${esc(profile.title)}</h3>
    <div class="small">${esc(profile.source_state)} · ${profile.controls.length} controls</div>
    <p>${esc(profile.boundary)}</p>
  </div>`).join('');
}

function renderCrosswalk(run) {
  if (!run) return;
  $('crosswalkResults').innerHTML = (run.crosswalk || []).map((profile) => `<div class="panel">
    <h3>${esc(profile.title || profile.profile_id)}</h3>
    <div class="inline">${Object.entries(profile.summary || {}).map(([k, v]) => `<span class="badge ${badgeClass(k)}">${esc(k)} ${esc(v)}</span>`).join('')}</div>
    <p class="muted">${esc(profile.boundary || '')}</p>
    <div class="stack">${(profile.controls || []).map((c) => `<div class="control ${esc(c.state)}"><strong>${esc(c.control_id)} · ${esc(c.title)}</strong><div class="hint">observed: ${esc((c.observed_evidence_fields || []).join(', ') || 'none')}</div><div class="hint">missing: ${esc((c.missing_evidence_fields || []).join(', ') || 'none')}</div></div>`).join('')}</div>
  </div>`).join('') || '<div class="notice">该运行未声明标准映射档案。</div>';
}

async function loadNodes() {
  const data = await api('/api/nodes');
  state.nodes = data.nodes || [];
  $('nodeCards').innerHTML = state.nodes.map((node) => `<div class="profile-card"><div class="eyebrow">${esc(node.jurisdiction)}</div><h3>${esc(node.name)}</h3><div class="small">${esc(node.id)} · ${esc(node.trust_state)}</div><p>${esc(node.operator)}</p><div>${(node.languages || []).map((x) => `<span class="tag">${esc(x)}</span>`).join('')}</div><div class="hint">attestation: ${esc(node.attestation_mode)}</div></div>`).join('');
}

function downloadJson(name, value) {
  const blob = new Blob([pretty(value) + '\n'], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function exportBundle() {
  const runId = $('exportRun').value;
  if (!runId) throw new Error('请选择运行记录');
  const bundle = await api('/api/export', {method: 'POST', body: JSON.stringify({run_id: runId})});
  $('exportResult').textContent = pretty(bundle);
  $('importBundle').value = pretty(bundle);
  downloadJson(`${bundle.bundle_id}.json`, bundle);
  await loadAudit();
  toast('脱敏证据包已生成；原始输入内容未导出');
}

function parseImportEditor() {
  try { return JSON.parse($('importBundle').value); }
  catch (error) { throw new Error(`证据包 JSON 无效：${error.message}`); }
}

async function verifyBundleOnly() {
  const result = await api('/api/bundle/verify', {method: 'POST', body: JSON.stringify({bundle: parseImportEditor()})});
  $('importResult').textContent = pretty(result);
}

async function importBundle() {
  const result = await api('/api/import', {method: 'POST', body: JSON.stringify({bundle: parseImportEditor()})});
  $('importResult').textContent = pretty(result);
  await Promise.all([loadImports(), loadAudit()]);
  toast(`外部证据已记录：${result.status}`);
}

async function loadImports() {
  const data = await api('/api/imports');
  state.imports = data.imports || [];
  $('importsList').innerHTML = state.imports.map((item) => `<div class="control ${item.status === 'accepted_external_evidence' ? 'observed' : 'missing'}"><strong>${esc(item.bundle_id)}</strong><div>${esc(item.status)} · source ${esc(item.source_node_id)}</div><div class="hint">authority_inherited=${esc(item.verification?.authority_inherited)}</div></div>`).join('') || '<div class="muted">暂无外部证据导入记录</div>';
}

async function createChallenge() {
  let protocol;
  try { protocol = JSON.parse($('challengeProtocol').value); }
  catch (error) { throw new Error(`挑战协议 JSON 无效：${error.message}`); }
  const body = {run_id: $('challengeRun').value, claim_id: $('challengeClaim').value.trim(), title: $('challengeTitle').value.trim(), protocol};
  if (!body.run_id || !body.claim_id || !body.title) throw new Error('运行、主张 ID 和标题均不能为空');
  const result = await api('/api/challenges', {method: 'POST', body: JSON.stringify(body)});
  toast(`挑战记录已建立：${result.id}`);
  await loadChallenges();
}

async function loadChallenges() {
  const data = await api('/api/challenges');
  state.challenges = data.challenges || [];
  $('challengeList').innerHTML = state.challenges.map((item) => `<div class="control ${item.status === 'open' ? 'partial' : 'observed'}"><strong>${esc(item.title)}</strong><div>${esc(item.id)} · ${esc(item.status)}</div><div class="hint">run ${esc(item.run_id)} · claim ${esc(item.claim_id)}</div><pre>${esc(pretty(item.protocol))}</pre></div>`).join('') || '<div class="muted">暂无挑战记录</div>';
}

function renderMesh(run) {
  if (!run) return;
  const active = new Set(run.mesh?.active_channels || []);
  const roles = ['D', 'I', 'K', 'W', 'P'];
  const cells = ['<div class="mesh-cell head">→</div>'];
  roles.forEach((target) => cells.push(`<div class="mesh-cell head">${target}</div>`));
  roles.forEach((source) => {
    cells.push(`<div class="mesh-cell head">${source}</div>`);
    roles.forEach((target) => {
      const channel = `${source}→${target}`;
      cells.push(`<div class="mesh-cell ${active.has(channel) ? 'active' : ''}" title="${esc(channel)}">${esc(channel)}</div>`);
    });
  });
  $('meshMatrix').innerHTML = cells.join('');
  const kernel = run.kernel || {};
  $('meshKernel').innerHTML = `<div class="control observed"><strong>范围</strong><div>${esc(kernel.scope || '')}</div></div>` +
    `<div class="control partial"><strong>关键事实 ${kernel.critical_facts?.length || 0}</strong>${(kernel.critical_facts || []).map((x) => `<div class="tag">${esc(x.fact)}</div>`).join('')}</div>` +
    `<div class="control observed"><strong>方法</strong><div>${esc(kernel.method || '')}</div><div class="hint">universal_essence_claim=${esc(kernel.universal_essence_claim)}</div></div>`;
  $('meshEdges').innerHTML = (run.mesh?.edges || []).map((edge) => `<tr><td><span class="tag">${esc(edge.channel)}</span></td><td>${esc(edge.source)}</td><td>${esc(edge.relation)}</td><td>${esc(edge.target)}</td><td>${esc(edge.source_state)}</td></tr>`).join('');
}

async function loadAudit() {
  try {
    const data = await api('/api/audit?limit=300');
    const v = data.verification;
    $('auditSummary').textContent = `valid=${v.valid} · event_count=${v.event_count} · head=${v.head_hash}`;
    $('auditTable').innerHTML = (data.events || []).map((event) => `<tr><td>${event.seq}</td><td>${esc(event.created_at)}</td><td>${esc(event.actor)}</td><td>${esc(event.action)}</td><td>${esc(event.object_type)} / ${esc(event.object_id)}</td><td><code>${esc(short(event.event_hash, 22))}</code></td></tr>`).join('');
  } catch (error) {
    $('auditSummary').textContent = `当前角色不可读取完整审计：${error.message}`;
    $('auditTable').innerHTML = '';
  }
}

function showView(name) {
  document.querySelectorAll('.view').forEach((view) => view.classList.toggle('active', view.id === `view-${name}`));
  document.querySelectorAll('#nav button').forEach((button) => button.classList.toggle('active', button.dataset.view === name));
}

function guarded(fn) {
  return async (...args) => {
    try { await fn(...args); }
    catch (error) { toast(error.message || String(error), true); }
  };
}

function wireEvents() {
  $('loginForm').addEventListener('submit', guarded(async (event) => {
    event.preventDefault();
    const result = await api('/api/login', {method: 'POST', body: JSON.stringify({username: $('username').value.trim(), password: $('password').value})});
    state.token = result.token;
    localStorage.setItem('waeg_token', result.token);
    setSignedIn(result.user);
    await loadWorkspace();
    toast('本地工作区已登录');
  }));
  $('logoutBtn').addEventListener('click', () => signOut());
  document.querySelectorAll('#nav button').forEach((button) => button.addEventListener('click', () => showView(button.dataset.view)));
  $('refreshOverview').addEventListener('click', guarded(loadOverview));
  $('portfolioSearch').addEventListener('click', guarded(() => loadPortfolio($('portfolioCluster').value, $('portfolioQuery').value.trim())));
  $('portfolioQuery').addEventListener('keydown', guarded(async (event) => { if (event.key === 'Enter') await loadPortfolio($('portfolioCluster').value, $('portfolioQuery').value.trim()); }));
  $('reloadCapsules').addEventListener('click', guarded(loadCapsules));
  $('runCapsuleBtn').addEventListener('click', guarded(executeCapsule));
  $('saveCapsuleBtn').addEventListener('click', guarded(saveCapsule));
  $('reloadRuns').addEventListener('click', guarded(loadRuns));
  $('compareBtn').addEventListener('click', guarded(compareRuns));
  $('crosswalkRun').addEventListener('change', guarded(async () => renderCrosswalk(await api(`/api/runs/${encodeURIComponent($('crosswalkRun').value)}`))));
  $('meshRun').addEventListener('change', guarded(async () => renderMesh(await api(`/api/runs/${encodeURIComponent($('meshRun').value)}`))));
  $('exportBtn').addEventListener('click', guarded(exportBundle));
  $('verifyBundleBtn').addEventListener('click', guarded(verifyBundleOnly));
  $('importBundleBtn').addEventListener('click', guarded(importBundle));
  $('challengeBtn').addEventListener('click', guarded(createChallenge));
  $('reloadAudit').addEventListener('click', guarded(loadAudit));
}

document.addEventListener('DOMContentLoaded', async () => {
  wireEvents();
  await checkHealth();
  await restoreSession();
});
