from __future__ import annotations

import copy
import json
import os
import platform
import py_compile
import shutil
import subprocess
import sys
import time
import unittest
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable

from waeg.constants import DIKWP_CHANNELS, ROLES
from waeg.service import ConflictError, Service
from waeg.util import canonical_json, sha256_text, utc_now
from waeg.validation import validate_capsule, validate_crosswalk_profile, validate_node


class Collector:
    def __init__(self) -> None:
        self.items: list[dict[str, Any]] = []

    def add(self, category: str, name: str, passed: bool, details: Any = None) -> None:
        self.items.append({"category": category, "name": name, "passed": bool(passed), "details": details})

    def check(self, category: str, name: str, fn: Callable[[], Any]) -> Any:
        try:
            value = fn()
            passed = bool(value) if isinstance(value, bool) else True
            self.add(category, name, passed, None if value is True else value)
            return value
        except Exception as exc:  # QA must preserve the failure, not hide it.
            self.add(category, name, False, {"type": type(exc).__name__, "message": str(exc)})
            return None


class RecordingResult(unittest.TestResult):
    def __init__(self, collector: Collector):
        super().__init__()
        self.collector = collector

    def addSuccess(self, test):  # type: ignore[no-untyped-def]
        super().addSuccess(test)
        self.collector.add("unit_api", str(test), True)

    def addFailure(self, test, err):  # type: ignore[no-untyped-def]
        super().addFailure(test, err)
        self.collector.add("unit_api", str(test), False, self._exc_info_to_string(err, test))

    def addError(self, test, err):  # type: ignore[no-untyped-def]
        super().addError(test, err)
        self.collector.add("unit_api", str(test), False, self._exc_info_to_string(err, test))

    def addSkip(self, test, reason):  # type: ignore[no-untyped-def]
        super().addSkip(test, reason)
        self.collector.add("unit_api", str(test), False, {"skipped": reason})


def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _schema_tools() -> tuple[Any, Any]:
    from jsonschema import Draft202012Validator, FormatChecker
    return Draft202012Validator, FormatChecker


def _run_unit_suite(root: Path, collector: Collector) -> None:
    loader = unittest.TestLoader()
    suite = loader.discover(str(root / "tests"), pattern="test_*.py", top_level_dir=str(root))
    result = RecordingResult(collector)
    suite.run(result)


def _static_checks(root: Path, collector: Collector) -> None:
    py_files = sorted([p for p in root.rglob("*.py") if "__pycache__" not in p.parts])
    for path in py_files:
        collector.check("compile_static", f"python compile: {path.relative_to(root)}", lambda p=path: py_compile.compile(str(p), doraise=True) or True)

    app_js = root / "web/app.js"
    node = shutil.which("node")
    if node:
        def node_check() -> bool:
            proc = subprocess.run([node, "--check", str(app_js)], capture_output=True, text=True, timeout=30)
            if proc.returncode:
                raise RuntimeError(proc.stderr.strip())
            return True
        collector.check("compile_static", "JavaScript syntax: web/app.js", node_check)
    else:
        text = app_js.read_text(encoding="utf-8")
        collector.add("compile_static", "JavaScript fallback structural check", text.count("{") == text.count("}"), "node executable unavailable")

    html = (root / "web/index.html").read_text(encoding="utf-8")
    css = (root / "web/styles.css").read_text(encoding="utf-8")
    server = (root / "waeg/server.py").read_text(encoding="utf-8")
    adapters = (root / "waeg/adapters.py").read_text(encoding="utf-8")
    federation = (root / "waeg/federation.py").read_text(encoding="utf-8")
    service = (root / "waeg/service.py").read_text(encoding="utf-8")
    expected_views = ["overview", "portfolio", "capsules", "runs", "compare", "crosswalk", "federation", "challenges", "mesh", "audit"]
    for view in expected_views:
        collector.add("compile_static", f"browser view present: {view}", f'id="view-{view}"' in html)
    for asset in ["/styles.css", "/app.js"]:
        collector.add("compile_static", f"browser asset linked: {asset}", asset in html)
    for selector in [".mesh-matrix", ".status-grid", ".codebox", ".toast", ".card-grid"]:
        collector.add("compile_static", f"CSS selector present: {selector}", selector in css)
    for header in ["Content-Security-Policy", "X-Content-Type-Options", "X-Frame-Options", "Referrer-Policy"]:
        collector.add("security_boundary", f"HTTP security header: {header}", header in server)
    collector.add("security_boundary", "HTTP body size bounded", "MAX_BODY = 5_000_000" in server)
    collector.add("security_boundary", "adapter never executes tools", "tool_execution_performed\": False" in adapters or '"tool_execution_performed": False' in adapters)
    collector.add("security_boundary", "network endpoint allowlist present", "WAEG_ALLOWED_HOSTS" in adapters)
    collector.add("security_boundary", "raw input export explicitly false", '"raw_input_content_exported": False' in federation)
    collector.add("security_boundary", "authority inheritance explicitly false", '"authority_inherited": False' in federation)
    collector.add("security_boundary", "non-scalar comparison declared", '"no_scalar_ranking": True' in service)
    collector.add("security_boundary", "no forced 25-cell population declared", "no_forced_25_cell_population" in (root / "waeg/mesh.py").read_text(encoding="utf-8"))

    dockerfile = (root / "Dockerfile").read_text(encoding="utf-8")
    compose = (root / "docker-compose.yml").read_text(encoding="utf-8")
    for marker in ["USER waeg", "HEALTHCHECK", "PYTHONDONTWRITEBYTECODE"]:
        collector.add("deployment_static", f"Dockerfile marker: {marker}", marker in dockerfile)
    for marker in ["read_only: true", "no-new-privileges:true", "cap_drop", "127.0.0.1:8810:8810"]:
        collector.add("deployment_static", f"Compose marker: {marker}", marker in compose)


def _json_and_schema_checks(root: Path, collector: Collector) -> None:
    json_files = sorted([p for p in root.rglob("*.json") if "outputs" not in p.parts and p.name not in {"manifest.json"}])
    for path in json_files:
        collector.check("json_syntax", f"JSON parse: {path.relative_to(root)}", lambda p=path: _load(p) is not None)

    Draft202012Validator, FormatChecker = _schema_tools()
    schema_files = sorted((root / "schemas").glob("*.schema.json"))
    schemas = {}
    for path in schema_files:
        schema = _load(path)
        schemas[path.name] = schema
        collector.check("schema", f"Schema self-check: {path.name}", lambda s=schema: Draft202012Validator.check_schema(s) is None)

    mappings = [
        ("capsule.schema.json", sorted((root / "data/capsules").glob("*.json"))),
        ("node.schema.json", sorted((root / "data/nodes").glob("*.json"))),
        ("crosswalk_profile.schema.json", sorted((root / "data/crosswalk_profiles").glob("*.json"))),
        ("portfolio_snapshot.schema.json", [root / "data/portfolio_snapshot.json"]),
    ]
    for schema_name, instances in mappings:
        validator = Draft202012Validator(schemas[schema_name], format_checker=FormatChecker())
        for path in instances:
            def validate_instance(v=validator, p=path) -> bool:
                errors = sorted(v.iter_errors(_load(p)), key=lambda e: list(e.path))
                if errors:
                    raise AssertionError(errors[0].message)
                return True
            collector.check("schema", f"Instance validation: {path.relative_to(root)}", validate_instance)

    try:
        import yaml
        openapi = yaml.safe_load((root / "openapi.yaml").read_text(encoding="utf-8"))
        collector.add("openapi", "OpenAPI YAML parse", isinstance(openapi, dict))
        collector.add("openapi", "OpenAPI version 3.1.0", openapi.get("openapi") == "3.1.0")
        collector.add("openapi", "OpenAPI has 20 paths", len(openapi.get("paths", {})) == 20, len(openapi.get("paths", {})))
        for path in ["/api/health", "/api/login", "/api/capsules", "/api/runs", "/api/compare", "/api/export", "/api/import", "/api/audit"]:
            collector.add("openapi", f"OpenAPI route: {path}", path in openapi.get("paths", {}))
    except Exception as exc:
        collector.add("openapi", "OpenAPI YAML parse", False, str(exc))


def _data_integrity_checks(root: Path, collector: Collector) -> None:
    portfolio = _load(root / "data/portfolio_snapshot.json")
    projects = portfolio["projects"]
    clusters = Counter(x["cluster"] for x in projects)
    collector.add("portfolio_integrity", "observed repository total = 220", portfolio["observed_repository_total"] == 220)
    collector.add("portfolio_integrity", "curated project count = 129", portfolio["curated_project_count"] == 129 == len(projects))
    collector.add("portfolio_integrity", "project ids unique", len({x["id"] for x in projects}) == len(projects))
    collector.add("portfolio_integrity", "repository names unique", len({x["repo_name"] for x in projects}) == len(projects))
    collector.add("portfolio_integrity", "12 relationship clusters", len(clusters) == 12, dict(clusters))
    for cluster, count in sorted(clusters.items()):
        collector.add("portfolio_integrity", f"cluster non-empty: {cluster}", count > 0, count)
    for item in projects:
        ok = all([
            item["source_url"].startswith("https://github.com/YucongDuan"),
            bool(item["integration_slots"]),
            bool(item["source_state"]),
            bool(item["evidence_state"]),
            item["observed_at"] == "2026-07-21",
        ])
        collector.add("portfolio_records", f"portfolio record fields: {item['repo_name']}", ok)

    capsule_ids = set()
    for path in sorted((root / "data/capsules").glob("*.json")):
        capsule = _load(path)
        collector.check("capsule_integrity", f"manual capsule validation: {capsule['id']}", lambda c=capsule: validate_capsule(c)["id"] == c["id"])
        collector.add("capsule_integrity", f"capsule id unique: {capsule['id']}", capsule["id"] not in capsule_ids)
        capsule_ids.add(capsule["id"])
        collector.add("capsule_integrity", f"input hashes valid: {capsule['id']}", all(x["sha256"] == sha256_text(x["content"]) for x in capsule["inputs"]))
        collector.add("capsule_integrity", f"all channels valid: {capsule['id']}", set(capsule["mesh"]["active_channels"]).issubset(set(DIKWP_CHANNELS)))
        collector.add("capsule_integrity", f"repeat count bounded: {capsule['id']}", 1 <= capsule["evaluation"]["repeat_count"] <= 10)

    for path in sorted((root / "data/nodes").glob("*.json")):
        node = _load(path)
        collector.check("node_integrity", f"node validation: {node['id']}", lambda n=node: validate_node(n)["id"] == n["id"])
        collector.add("node_integrity", f"node data residency declared: {node['id']}", bool(node["data_residency"]))
        collector.add("node_integrity", f"node capability declared: {node['id']}", bool(node["capabilities"]))

    crosswalk_ids = set()
    for path in sorted((root / "data/crosswalk_profiles").glob("*.json")):
        profile = _load(path)
        collector.check("crosswalk_integrity", f"crosswalk validation: {profile['id']}", lambda p=profile: validate_crosswalk_profile(p)["id"] == p["id"])
        collector.add("crosswalk_integrity", f"crosswalk id unique: {profile['id']}", profile["id"] not in crosswalk_ids)
        crosswalk_ids.add(profile["id"])
        collector.add("crosswalk_integrity", f"crosswalk source URLs: {profile['id']}", all(x.startswith("https://") for x in profile["source_urls"]))
        collector.add("crosswalk_integrity", f"crosswalk has boundary: {profile['id']}", bool(profile["boundary"]))
        collector.add("crosswalk_integrity", f"crosswalk controls unique: {profile['id']}", len({x["id"] for x in profile["controls"]}) == len(profile["controls"]))


def _runtime_checks(root: Path, db_path: Path, collector: Collector) -> None:
    for suffix in ("", "-wal", "-shm"):
        try:
            Path(str(db_path) + suffix).unlink()
        except FileNotFoundError:
            pass
    service = Service(root, db_path)
    seeded = service.initialize()
    collector.add("runtime", "seed portfolio count", seeded["seeded"]["portfolio"] == 129, seeded)
    counts = service.summary_counts()
    expected = {"portfolio_projects": 129, "capsules": 6, "nodes": 2, "runs": 0}
    for key, value in expected.items():
        collector.add("runtime", f"initial count {key}={value}", counts[key] == value, counts[key])
    collector.add("runtime", "audit valid after seed", service.db.verify_audit()["valid"])

    expected_gates = {
        "caps_public_service_bilingual": "REVIEW",
        "caps_agent_tool_boundary": "BLOCK",
        "caps_open_claim_replication": "REVIEW",
        "caps_cross_model_purpose": "HOLD",
        "caps_embodied_safety_synthetic": "REVIEW",
        "caps_low_resource_node": "REVIEW",
    }
    runs: dict[str, dict[str, Any]] = {}
    for index, (capsule_id, expected_gate) in enumerate(expected_gates.items(), start=1):
        run = service.run_capsule(capsule_id, "admin", adapter_name="mock", seed=20260720 + index)
        runs[capsule_id] = run
        collector.add("runtime_run", f"run completed: {capsule_id}", run["status"] == "completed")
        collector.add("runtime_run", f"expected gate: {capsule_id}", run["evaluation"]["statuses"]["gate"] == expected_gate, run["evaluation"]["statuses"])
        collector.add("runtime_run", f"repeatability passed: {capsule_id}", run["evaluation"]["checks"]["repeatability"]["passed"])
        collector.add("runtime_run", f"tool execution false: {capsule_id}", run["output"]["tool_execution_performed"] is False)
        collector.add("runtime_run", f"network unused: {capsule_id}", run["output"]["network_used"] is False)
        collector.add("runtime_run", f"mesh closure: {capsule_id}", run["mesh"]["closure_path_observed"])
        collector.add("runtime_run", f"mesh M4: {capsule_id}", run["mesh"]["mesh_examination"] == "M4", run["mesh"]["mesh_examination"])
        collector.add("runtime_run", f"mesh edges structurally valid: {capsule_id}", not run["mesh"]["validation_errors"])
        collector.add("runtime_run", f"kernel scoped: {capsule_id}", run["kernel"]["universal_essence_claim"] is False)
        collector.add("runtime_run", f"six crosswalk profiles: {capsule_id}", len(run["crosswalk"]) == 6)
        collector.add("runtime_run", f"input/output hashes present: {capsule_id}", len(run["input_hash"]) == 64 and len(run["output_hash"]) == 64)
        collector.add("runtime_run", f"evidence items present: {capsule_id}", len(run["evidence_items"]) >= 1)

    compliant = runs["caps_public_service_bilingual"]
    blocked = runs["caps_agent_tool_boundary"]
    drift = runs["caps_cross_model_purpose"]
    collector.add("runtime_semantics", "compliant semantic stability S4", compliant["evaluation"]["statuses"]["semantic_stability"] == "S4")
    collector.add("runtime_semantics", "tool overreach gate BLOCK", blocked["evaluation"]["statuses"]["gate"] == "BLOCK")
    collector.add("runtime_semantics", "tool overreach requested but not executed", blocked["evaluation"]["facts"]["unauthorized_tool_request_present"] and not blocked["output"]["tool_execution_performed"])
    collector.add("runtime_semantics", "purpose drift gate HOLD", drift["evaluation"]["statuses"]["gate"] == "HOLD")
    collector.add("runtime_semantics", "purpose drift semantic stability S1", drift["evaluation"]["statuses"]["semantic_stability"] == "S1")

    comparison = service.compare_runs(compliant["id"], blocked["id"])
    collector.add("runtime_compare", "comparison no scalar ranking", comparison["no_scalar_ranking"] is True)
    collector.add("runtime_compare", "comparison has task records", len(comparison["tasks"]) >= 1)
    collector.add("runtime_compare", "comparison has no score field", "score" not in comparison)

    challenge = service.create_challenge(compliant["id"], "task_zh-C1", "QA replication", {"method": "independent_replay"}, "replicator")
    collector.add("runtime_challenge", "challenge open", challenge["status"] == "open")
    resolved = service.resolve_challenge(challenge["id"], "inconclusive", {"reason": "QA synthetic"}, "replicator")
    collector.add("runtime_challenge", "challenge resolved", resolved["status"] == "inconclusive")
    collector.add("runtime_challenge", "challenge resolution retained", resolved["resolution"]["reason"] == "QA synthetic")

    source_capsule = copy.deepcopy(service.get_capsule("caps_open_claim_replication")["payload"])
    source_capsule["id"] = "caps_qa_revision"
    source_capsule["title"] = "QA revision capsule"
    created = service.save_capsule(source_capsule, "designer")
    collector.add("runtime_revision", "capsule create revision 1", created["revision"] == 1)
    source_capsule["title"] = "QA revision capsule v2"
    updated = service.save_capsule(source_capsule, "designer", expected_revision=1)
    collector.add("runtime_revision", "capsule update revision 2", updated["revision"] == 2)
    try:
        service.save_capsule(source_capsule, "designer", expected_revision=1)
        collector.add("runtime_revision", "stale revision rejected", False)
    except ConflictError:
        collector.add("runtime_revision", "stale revision rejected", True)

    public_bundle = service.export(compliant["id"], "admin")
    restricted_bundle = service.export(blocked["id"], "admin")
    collector.add("runtime_federation", "public bundle excludes raw inputs", public_bundle["redaction"]["raw_input_content_exported"] is False)
    collector.add("runtime_federation", "public bundle includes allowed output", public_bundle["redaction"]["output_exported"] is True)
    collector.add("runtime_federation", "restricted bundle hides output", restricted_bundle["redaction"]["output_exported"] is False and restricted_bundle["run"]["output"].get("redacted") is True)
    raw_contents = [x["content"] for x in service.get_capsule("caps_public_service_bilingual")["payload"]["inputs"]]
    bundle_text = canonical_json(public_bundle)
    collector.add("runtime_federation", "raw input strings absent from bundle", all(text not in bundle_text for text in raw_contents))
    verification = service.verify_external_bundle(public_bundle)
    collector.add("runtime_federation", "bundle structural hashes valid", verification["structural_valid"])
    collector.add("runtime_federation", "known-node HMAC verified", verification["attestation_state"] == "verified_shared_secret", verification)
    collector.add("runtime_federation", "bundle authority not inherited", verification["authority_inherited"] is False)
    imported = service.import_external_bundle(public_bundle, "replicator")
    collector.add("runtime_federation", "valid bundle accepted as external evidence", imported["status"] == "accepted_external_evidence")
    tampered = copy.deepcopy(public_bundle)
    tampered["run"]["status"] = "tampered"
    rejected = service.import_external_bundle(tampered, "replicator")
    collector.add("runtime_federation", "tampered bundle rejected", rejected["status"] == "rejected_invalid_structure")

    audit = service.db.verify_audit()
    collector.add("runtime_audit", "audit valid after all writes", audit["valid"], audit)
    collector.add("runtime_audit", "audit event count expanded", audit["event_count"] > 20, audit["event_count"])
    before_restart = service.summary_counts()
    restarted = Service(root, db_path)
    restarted.initialize()
    after_restart = restarted.summary_counts()
    collector.add("runtime_restart", "restart preserves run count", before_restart["runs"] == after_restart["runs"])
    collector.add("runtime_restart", "restart does not duplicate portfolio", after_restart["portfolio_projects"] == 129)
    collector.add("runtime_restart", "restart does not duplicate seed capsules", after_restart["capsules"] == 7)
    collector.add("runtime_restart", "audit valid after restart", restarted.db.verify_audit()["valid"])

    for role, permissions in ROLES.items():
        collector.add("role_matrix", f"role declared: {role}", isinstance(permissions, set) and bool(permissions))

    # Validate generated objects using the packaged schemas.
    Draft202012Validator, _ = _schema_tools()
    run_schema = Draft202012Validator(_load(root / "schemas/run.schema.json"))
    bundle_schema = Draft202012Validator(_load(root / "schemas/evidence_bundle.schema.json"))
    for capsule_id, run in runs.items():
        errors = list(run_schema.iter_errors(run))
        collector.add("generated_schema", f"generated run schema: {capsule_id}", not errors, errors[0].message if errors else None)
    for name, bundle in [("public", public_bundle), ("restricted", restricted_bundle)]:
        errors = list(bundle_schema.iter_errors(bundle))
        collector.add("generated_schema", f"generated bundle schema: {name}", not errors, errors[0].message if errors else None)

    # Export deterministic examples without retaining the QA database.
    examples = root / "examples"
    examples.mkdir(exist_ok=True)
    (examples / "example_run_receipt.json").write_text(json.dumps(compliant, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (examples / "example_evidence_bundle.json").write_text(json.dumps(public_bundle, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (examples / "example_comparison.json").write_text(json.dumps(comparison, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    collector.add("examples", "example run written", (examples / "example_run_receipt.json").is_file())
    collector.add("examples", "example bundle written", (examples / "example_evidence_bundle.json").is_file())
    collector.add("examples", "example comparison written", (examples / "example_comparison.json").is_file())

    # Remove runtime DB and sidecars so the release remains clean.
    for suffix in ("", "-wal", "-shm"):
        try:
            Path(str(db_path) + suffix).unlink()
        except FileNotFoundError:
            pass
    collector.add("release_cleanliness", "QA database removed", not db_path.exists())


def run_all(root: Path, db_path: Path) -> dict[str, Any]:
    root = Path(root).resolve()
    db_path = Path(db_path).resolve()
    start = time.perf_counter()
    collector = Collector()
    _static_checks(root, collector)
    _json_and_schema_checks(root, collector)
    _data_integrity_checks(root, collector)
    _run_unit_suite(root, collector)
    _runtime_checks(root, db_path, collector)
    duration = round(time.perf_counter() - start, 3)

    counts = Counter(item["category"] for item in collector.items)
    passed_by_category = defaultdict(int)
    for item in collector.items:
        if item["passed"]:
            passed_by_category[item["category"]] += 1
    categories = {
        category: {"passed": passed_by_category[category], "total": total}
        for category, total in sorted(counts.items())
    }
    passed = sum(1 for item in collector.items if item["passed"])
    failed = len(collector.items) - passed
    return {
        "system": "DIKWP-Mesh 4.1 WorldAI Evidence Grid",
        "version": "1.0.0",
        "generated_at": utc_now(),
        "duration_seconds": duration,
        "environment": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "node": shutil.which("node") or "unavailable",
        },
        "passed": passed,
        "failed": failed,
        "total": len(collector.items),
        "categories": categories,
        "failures": [item for item in collector.items if not item["passed"]],
        "checks": collector.items,
        "boundary": "Engineering QA verifies packaged behavior and internal invariants. It does not certify external truth, legal conformity, field effectiveness, public authority, model consciousness or universal safety.",
    }


if __name__ == "__main__":
    result = run_all(Path(__file__).resolve().parent.parent, Path(__file__).resolve().parent.parent / "outputs/qa_runtime.sqlite3")
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
    raise SystemExit(0 if result["failed"] == 0 else 1)
