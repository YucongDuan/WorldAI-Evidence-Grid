from __future__ import annotations

import copy
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from waeg.auth import can, hash_password, verify_password
from waeg.constants import DEFAULT_DEMO_PASSWORD, DIKWP_CHANNELS
from waeg.server import Handler, WAEGHTTPServer
from waeg.service import ConflictError, Service
from waeg.util import canonical_json, sha256_text
from waeg.validation import ValidationError, validate_capsule

ROOT = Path(__file__).resolve().parent.parent


class UtilityTests(unittest.TestCase):
    def test_canonical_json_is_order_stable(self) -> None:
        self.assertEqual(canonical_json({"b": 1, "a": 2}), canonical_json({"a": 2, "b": 1}))

    def test_hash_is_stable(self) -> None:
        self.assertEqual(sha256_text("abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")

    def test_password_hash_and_verify(self) -> None:
        salt, digest = hash_password("correct-horse")
        self.assertTrue(verify_password("correct-horse", salt, digest))
        self.assertFalse(verify_password("wrong-horse", salt, digest))

    def test_permissions(self) -> None:
        self.assertTrue(can("admin", "node_write"))
        self.assertTrue(can("public_observer", "read"))
        self.assertFalse(can("public_observer", "run"))

    def test_all_25_channels_are_unique(self) -> None:
        self.assertEqual(len(DIKWP_CHANNELS), 25)
        self.assertEqual(len(set(DIKWP_CHANNELS)), 25)


class ValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.capsule = json.loads((ROOT / "data/capsules/caps_public_service_bilingual.json").read_text(encoding="utf-8"))

    def test_valid_capsule(self) -> None:
        self.assertEqual(validate_capsule(copy.deepcopy(self.capsule))["id"], self.capsule["id"])

    def test_invalid_input_hash(self) -> None:
        bad = copy.deepcopy(self.capsule)
        bad["inputs"][0]["sha256"] = "0" * 64
        with self.assertRaises(ValidationError):
            validate_capsule(bad)

    def test_unknown_evidence_reference(self) -> None:
        bad = copy.deepcopy(self.capsule)
        bad["tasks"][0]["expected_evidence_refs"].append("UNKNOWN")
        with self.assertRaises(ValidationError):
            validate_capsule(bad)

    def test_unknown_channel(self) -> None:
        bad = copy.deepcopy(self.capsule)
        bad["mesh"]["active_channels"].append("X→Y")
        with self.assertRaises(ValidationError):
            validate_capsule(bad)


class ServiceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tmp = tempfile.TemporaryDirectory(prefix="waeg-unit-")
        cls.db_path = Path(cls.tmp.name) / "unit.sqlite3"
        cls.service = Service(ROOT, cls.db_path)
        cls.initial = cls.service.initialize()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.tmp.cleanup()

    def test_01_seed_counts(self) -> None:
        counts = self.service.summary_counts()
        self.assertEqual(counts["portfolio_projects"], 129)
        self.assertEqual(counts["capsules"], 6)
        self.assertEqual(counts["nodes"], 2)

    def test_02_seed_is_idempotent(self) -> None:
        seeded = self.service.initialize()["seeded"]
        self.assertEqual(seeded, {"portfolio": 0, "capsules": 0, "nodes": 0})

    def test_03_login(self) -> None:
        session = self.service.login("admin", DEFAULT_DEMO_PASSWORD)
        self.assertIsNotNone(session)
        assert session is not None
        user = self.service.db.user_for_token(session["token"])
        self.assertEqual(user["role"], "admin")
        self.assertIsNone(self.service.login("admin", "not-the-password"))

    def test_04_portfolio_search(self) -> None:
        result = self.service.portfolio(cluster="semantic_runtime")
        self.assertGreater(result["returned_count"], 10)
        self.assertTrue(all(x["cluster"] == "semantic_runtime" for x in result["projects"]))
        self.assertEqual(result["observed_repository_total"], 220)

    def test_05_compliant_run(self) -> None:
        run = self.service.run_capsule("caps_public_service_bilingual", "admin", adapter_name="mock", seed=11)
        self.__class__.compliant_run_id = run["id"]
        self.assertEqual(run["evaluation"]["statuses"]["semantic_stability"], "S4")
        self.assertEqual(run["evaluation"]["statuses"]["gate"], "REVIEW")
        self.assertEqual(run["mesh"]["mesh_examination"], "M4")
        self.assertTrue(run["mesh"]["closure_path_observed"])
        self.assertTrue(run["kernel"]["universal_essence_claim"] is False)

    def test_06_tool_overreach_is_blocked_without_execution(self) -> None:
        run = self.service.run_capsule("caps_agent_tool_boundary", "admin", adapter_name="mock", seed=12)
        self.__class__.blocked_run_id = run["id"]
        self.assertEqual(run["evaluation"]["statuses"]["gate"], "BLOCK")
        self.assertTrue(run["evaluation"]["facts"]["unauthorized_tool_request_present"])
        self.assertFalse(run["output"]["tool_execution_performed"])
        self.assertEqual(run["evaluation"]["statuses"]["evidence_reliability"], "Blocked")

    def test_07_purpose_drift_is_held(self) -> None:
        run = self.service.run_capsule("caps_cross_model_purpose", "admin", adapter_name="mock", seed=13)
        self.__class__.drift_run_id = run["id"]
        self.assertEqual(run["evaluation"]["statuses"]["gate"], "HOLD")
        self.assertEqual(run["evaluation"]["statuses"]["semantic_stability"], "S1")
        self.assertTrue(run["evaluation"]["facts"]["purpose_conflict_present"])

    def test_08_comparison_is_non_scalar(self) -> None:
        data = self.service.compare_runs(self.compliant_run_id, self.blocked_run_id)
        self.assertTrue(data["no_scalar_ranking"])
        self.assertGreater(len(data["tasks"]), 0)
        self.assertNotIn("score", data)

    def test_09_challenge_lifecycle(self) -> None:
        challenge = self.service.create_challenge(self.compliant_run_id, "task_zh-C1", "replication", {"seed": 11}, "replicator")
        self.assertEqual(challenge["status"], "open")
        resolved = self.service.resolve_challenge(challenge["id"], "inconclusive", {"reason": "independent node unavailable"}, "replicator")
        self.assertEqual(resolved["status"], "inconclusive")
        self.assertEqual(resolved["resolution"]["reason"], "independent node unavailable")

    def test_10_capsule_optimistic_revision(self) -> None:
        source = self.service.get_capsule("caps_open_claim_replication")["payload"]
        new = copy.deepcopy(source)
        new["id"] = "caps_unit_revision"
        new["title"] = "Unit revision capsule"
        created = self.service.save_capsule(new, "designer")
        self.assertEqual(created["revision"], 1)
        new["title"] = "Unit revision capsule updated"
        updated = self.service.save_capsule(new, "designer", expected_revision=1)
        self.assertEqual(updated["revision"], 2)
        with self.assertRaises(ConflictError):
            self.service.save_capsule(new, "designer", expected_revision=1)

    def test_11_network_adapter_requires_explicit_authorization(self) -> None:
        with self.assertRaises(Exception):
            self.service.run_capsule(
                "caps_public_service_bilingual", "admin", adapter_name="openai_compatible",
                allow_network=True, endpoint="http://127.0.0.1:1/v1/chat/completions", model="local",
            )

    def test_12_public_bundle_exports_output(self) -> None:
        bundle = self.service.export(self.compliant_run_id, "admin")
        self.__class__.public_bundle = bundle
        self.assertFalse(bundle["redaction"]["raw_input_content_exported"])
        self.assertTrue(bundle["redaction"]["output_exported"])
        verification = self.service.verify_external_bundle(bundle)
        self.assertTrue(verification["structural_valid"])
        self.assertFalse(verification["authority_inherited"])

    def test_13_restricted_bundle_redacts_output(self) -> None:
        bundle = self.service.export(self.blocked_run_id, "admin")
        self.assertFalse(bundle["redaction"]["output_exported"])
        self.assertTrue(bundle["run"]["output"]["redacted"])

    def test_14_import_never_inherits_authority(self) -> None:
        result = self.service.import_external_bundle(self.public_bundle, "replicator")
        self.assertEqual(result["status"], "accepted_external_evidence")
        self.assertFalse(result["verification"]["authority_inherited"])

    def test_15_tampered_bundle_is_rejected(self) -> None:
        tampered = copy.deepcopy(self.public_bundle)
        tampered["run"]["status"] = "tampered"
        result = self.service.import_external_bundle(tampered, "replicator")
        self.assertEqual(result["status"], "rejected_invalid_structure")
        self.assertFalse(result["verification"]["structural_valid"])

    def test_16_audit_chain_valid(self) -> None:
        audit = self.service.db.verify_audit()
        self.assertTrue(audit["valid"])
        self.assertGreater(audit["event_count"], 10)


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tmp = tempfile.TemporaryDirectory(prefix="waeg-http-")
        cls.service = Service(ROOT, Path(cls.tmp.name) / "http.sqlite3")
        cls.service.initialize()
        cls.server = WAEGHTTPServer(("127.0.0.1", 0), Handler, cls.service)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)
        cls.tmp.cleanup()

    @classmethod
    def request(cls, path: str, *, method: str = "GET", body: dict | None = None, token: str | None = None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(cls.base + path, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=10) as response:
            raw = response.read()
            content_type = response.headers.get("Content-Type", "")
            return response.status, content_type, json.loads(raw) if "json" in content_type else raw.decode("utf-8")

    def test_01_health_is_public(self) -> None:
        status, _, body = self.request("/api/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "ok")

    def test_02_static_workbench(self) -> None:
        status, content_type, body = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn("text/html", content_type)
        self.assertIn("世界AI证据网格", body)

    def test_03_auth_and_run_api(self) -> None:
        status, _, login = self.request("/api/login", method="POST", body={"username": "admin", "password": DEFAULT_DEMO_PASSWORD})
        self.assertEqual(status, 200)
        token = login["token"]
        status, _, portfolio = self.request("/api/portfolio", token=token)
        self.assertEqual(status, 200)
        self.assertEqual(portfolio["curated_project_count"], 129)
        status, _, run = self.request("/api/runs", method="POST", token=token, body={"capsule_id": "caps_public_service_bilingual", "adapter": "mock", "seed": 77})
        self.assertEqual(status, 201)
        self.assertEqual(run["evaluation"]["statuses"]["semantic_stability"], "S4")
        status, _, detail = self.request(f"/api/runs/{run['id']}", token=token)
        self.assertEqual(status, 200)
        self.assertEqual(detail["id"], run["id"])

    def test_04_unauthenticated_private_api_is_denied(self) -> None:
        req = urllib.request.Request(self.base + "/api/capsules")
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=10)
        self.assertEqual(ctx.exception.code, 403)


if __name__ == "__main__":
    unittest.main(verbosity=2)
