# WAEG 系统架构

## 1. 逻辑架构

```text
┌──────────────────────────────────────────────────────────────┐
│ Browser Workbench                                             │
│ Portfolio · Capsules · Runs · Diff · Crosswalk · Federation  │
│ Challenge · Mesh · Audit                                     │
└──────────────────────────────┬───────────────────────────────┘
                               │ HTTP/JSON
┌──────────────────────────────▼───────────────────────────────┐
│ Standard-library HTTP API                                    │
│ Session RBAC · 5 MB limit · CSP · optimistic revisions       │
└──────────────────────────────┬───────────────────────────────┘
                               │
┌──────────────────────────────▼───────────────────────────────┐
│ Service Orchestration                                        │
│ Capsule → Adapter → Evaluation → Crosswalk → Mesh → Kernel   │
│ Challenge → Export/Verify/Import → Audit                     │
└───────────────┬──────────────────────────┬───────────────────┘
                │                          │
┌───────────────▼──────────────┐  ┌────────▼───────────────────┐
│ Adapter Boundary             │  │ Source-limited Registries  │
│ mock / replay                │  │ portfolio / node / policy  │
│ optional local HTTP models   │  │ capsule / standards        │
│ never executes tools         │  └────────────────────────────┘
└───────────────┬──────────────┘
                │
┌───────────────▼──────────────────────────────────────────────┐
│ SQLite WAL                                                    │
│ users · sessions · nodes · portfolio · capsules · runs       │
│ evidence · challenges · imports · hash-linked audit          │
└──────────────────────────────────────────────────────────────┘
```

## 2. 运行事务

一次运行按以下顺序完成：

1. 从 SQLite 读取指定胶囊及其 revision/hash；
2. 验证适配器、联网双重授权和端点白名单；
3. 按 repeat_count 运行适配器；
4. 记录运行时、Python、SQLite、输入清单、任务 prompt hash 和时间；
5. 对目的保持、锚点、证据引用、工具请求、网络、重复性和人工复核执行确定性检查；
6. 映射到来源限定的中国/全球控制项；
7. 构建 DIKWP×DIKWP 当前子图；
8. 逐个删除已观察事实，重算闭合签名，形成问题核；
9. 形成节点 HMAC 演示证明；
10. 在一个数据库事务中写入 run、evidence_items 和审计事件。

## 3. 数据模型

### Capsule

实验的可移植意图与输入边界。修订采用乐观锁，客户端必须提交 `expected_revision`。

### Run

不可变运行收据，保存：

```text
capsule revision/hash
adapter/model/seed
input/output hash
manifest
normalized output
evaluation
crosswalk
mesh
counterfactual kernel
attestation
source node
```

### EvidenceItem

对每个 claim 的 evidence reference 建立单独记录。状态 `linked` 或 `missing_or_unknown` 不表示事实真假，只表示声明引用是否链接到胶囊输入 ID。

### Challenge

对具体主张的独立复现/反证协议及状态。

### Node

法域、数据驻留、语言、能力和证明模式的来源限定护照。

### Import

外部证据包及本地验证状态。任何导入的 authority 均为 `false`。

### AuditEvent

保存上一事件哈希、负载哈希和当前事件哈希。

## 4. 适配器边界

所有模型输出被规范化为：

```json
{
  "task_id": "...",
  "language": "zh-CN",
  "answer": "...",
  "purpose_ack": "...",
  "claims": [
    {"id": "...", "text": "...", "evidence_refs": ["input-id"], "source_state": "..."}
  ],
  "requested_tools": [],
  "anchors_emitted": [],
  "residuals": []
}
```

缺失字段被留空并记录规范化残差，不由系统推断补齐。

## 5. 非标量状态推导

Gate 优先级：

```text
unsafe execution → KILL
unauthorized tool/network/execution policy violation → BLOCK
purpose conflict → HOLD
human review/evidence incomplete/anchor loss → REVIEW
otherwise → ALLOW
```

这些规则是项目本地运行规则，不是外部概念定义或监管分类。

## 6. 联邦证据包

导出对象的 canonical JSON 形成 payload hash；manifest 再形成 manifest hash；本地演示节点对 manifest hash 进行 HMAC-SHA256。验证分为：

```text
结构验证
payload hash 验证
manifest hash 验证
已知节点共享密钥验证
本地权威继承：始终 false
```

## 7. 依赖边界

核心运行依赖：

- Python 3.10+
- SQLite（Python 标准库绑定）
- 现代浏览器

QA 可选使用已安装的 `jsonschema`、`PyYAML` 和 Node.js 进行更强的 Schema、OpenAPI 和 JavaScript 静态验证；这些不是服务启动依赖。
