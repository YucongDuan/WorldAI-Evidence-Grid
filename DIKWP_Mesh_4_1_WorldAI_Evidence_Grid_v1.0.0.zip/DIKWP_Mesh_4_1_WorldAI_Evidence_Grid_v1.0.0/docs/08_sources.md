# 来源清单与状态

观察时点：2026-07-21。

## 1. GitHub

账户：

- https://github.com/YucongDuan

深读代表仓库：

- https://github.com/YucongDuan/DIKWP-MESH-RUNTIME-Commons-v1.0
- https://github.com/YucongDuan/DIKWP-MESH-TRUSTFABRIC-Commons-OS-v1.0.0
- https://github.com/YucongDuan/DIKWP-COOPSTACK-
- https://github.com/YucongDuan/DIKWP-NEURALINGUA-
- https://github.com/YucongDuan/DIKWP-ACRS-ClosedLab-v1.0.0
- https://github.com/YucongDuan/DIKWP-CREDENCE-
- https://github.com/YucongDuan/DIKWP-RealityLoop-OS
- https://github.com/YucongDuan/DIKWP-RELAY-
- https://github.com/YucongDuan/DIKWP-PACT-v0.1.0
- https://github.com/YucongDuan/DIKWP-P-Space-OS-v1.0
- https://github.com/YucongDuan/DIKWP-EIR-Mesh-OS
- https://github.com/YucongDuan/DIKWP-StandardForge-OS
- https://github.com/YucongDuan/DIKWP-EcosystemRouter-OS
- https://github.com/YucongDuan/DIKWP-ProofLedger-OS
- https://github.com/YucongDuan/DIKWP-IntentGuard-Agent-Firewall

来源状态：`readme_observed`。本交付未逐一执行这些仓库的代码。

其余策展记录来源状态主要为 `github_name_description_snapshot`，详见 `data/portfolio_snapshot.json`。

## 2. 中国官方来源

- 中国人工智能全球治理行动计划：
  https://www.mfa.gov.cn/zyxw/202507/t20250726_11677803.shtml
- 国务院关于深入实施“人工智能+”行动的意见：
  https://www.cac.gov.cn/2025-08/27/c_1758018277755538.htm
- 《人工智能 智能体互联》系列标准相关信息：
  https://std.samr.gov.cn/gb/search/gbDetailed?id=3BAB0AA8A7FC31E3E06397BE0A0AA43F
  https://www.ncsti.gov.cn/kjdt/scyq/zgckxc/zgcdt/202606/t20260629_250405.html

## 3. 全球官方来源

- NIST AI RMF：
  https://www.nist.gov/itl/ai-risk-management-framework
- NIST Generative AI Profile：
  https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence
- NIST AIRC：
  https://airc.nist.gov/
- EU GPAI Code：
  https://digital-strategy.ec.europa.eu/en/policies/contents-code-gpai
- EU AI Act overview：
  https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai
- UN Global Dialogue on AI Governance：
  https://www.un.org/global-dialogue-ai-governance/en

## 4. 来源边界

政策和标准页面用于形成工程材料映射，不用于生成法律意见或合规结论。GitHub README 用于提取公开项目陈述，不等于独立复现或验证。
