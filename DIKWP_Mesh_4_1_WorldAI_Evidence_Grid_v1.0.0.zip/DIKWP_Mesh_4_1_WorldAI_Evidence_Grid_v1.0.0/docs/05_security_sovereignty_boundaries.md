# 安全、主权和权威边界

## 1. 默认封闭

默认配置：

```text
host = 127.0.0.1
network adapter = disabled
external tools = never executed
physical device = no connector
raw input export = false
```

## 2. 网络双重授权

网络请求只有在以下关系同时成立时才可能发生：

```text
operator allow_network = true
AND capsule.safety.network_allowed = true
AND endpoint scheme = http/https
AND endpoint hostname is localhost or WAEG_ALLOWED_HOSTS
AND URL contains no embedded credential
```

这不是出站防火墙的替代品。生产部署仍需容器、网络策略和机构安全控制。

## 3. 工具边界

模型可能返回 tool calls。WAEG：

- 解析工具名；
- 与 capsule allowlist 比较；
- 将越权请求映射到 BLOCK；
- 保存请求记录；
- 不执行 shell、网络、文件、数据库、审批或物理设备工具。

## 4. 数据主权

Node passport 和 Capsule authority 分别保存法域与数据驻留。它们是来源声明，不是系统自动验证的法律事实。

联邦导出不包含原始输入内容。存在 restricted/secret 输入时，完整模型输出也不导出，仅保留 output hash。

## 5. 外部证据权威不继承

即使 bundle 的结构、payload hash、manifest hash 和 HMAC 均通过：

```text
authority_inherited = false
```

外部证据必须经过本地人员和机构程序，才能进入本地知识、决策或标准材料。

## 6. 身份与签名

本项目的 bearer token、workflow role 和 HMAC 是演示机制：

- 不验证真实姓名或执业/机构资格；
- 不连接统一身份认证；
- 不使用硬件密钥或证书；
- HMAC 不提供公开可验证身份和不可否认性。

## 7. 审计边界

SHA-256 链可检测数据库内审计事件的结构性篡改，但不能防止：

- 获得主机完全控制后的数据库和备份同时替换；
- 操作系统时间、用户身份或输入来源造假；
- 应用外部发生但未记录的行为。

生产环境需要外部只追加日志、时间戳服务、KMS 和独立审计存储。

## 8. 标准与法律边界

Crosswalk 仅说明本地运行事实是否存在。它不判断：

- 法律角色；
- 适用法；
- 合规性；
- 风险等级；
- 产品认证；
- 跨境数据许可；
- 现实安全或公平性。
