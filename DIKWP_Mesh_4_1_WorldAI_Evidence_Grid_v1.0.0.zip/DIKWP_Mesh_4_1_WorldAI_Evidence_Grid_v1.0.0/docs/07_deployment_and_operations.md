# 部署与运行

## 1. 本地运行

```bash
python run.py serve
```

首次启动创建 `data/waeg.sqlite3` 并幂等装载：

- 8 个演示工作流用户；
- 2 个节点护照；
- 6 个实验胶囊；
- 129 个策展项目记录。

重启不会重复插入这些对象。

## 2. 数据库位置

默认：

```text
data/waeg.sqlite3
```

独立运行：

```bash
python run.py --db /srv/waeg/node.sqlite3 serve --host 127.0.0.1 --port 8810
```

## 3. Docker

```bash
docker compose up --build
```

Compose 将数据卷挂载到 `/app/runtime-data`，服务监听容器内 `0.0.0.0:8810`。对外发布时应由反向代理提供 TLS、真实身份认证、访问控制和限流。

## 4. 可选本地模型

OpenAI-compatible：

```bash
export WAEG_ALLOWED_HOSTS=127.0.0.1,localhost
python run.py run \
  --capsule caps_public_service_bilingual \
  --adapter openai_compatible \
  --endpoint http://127.0.0.1:8000/v1/chat/completions \
  --model local-model \
  --allow-network
```

胶囊自身还必须设置 `network_allowed=true`。

Ollama：

```bash
python run.py run \
  --capsule <network-enabled-capsule> \
  --adapter ollama \
  --endpoint http://127.0.0.1:11434/api/chat \
  --model llama3.2 \
  --allow-network
```

默认胶囊为离线安全状态，不能直接用于网络适配器。

## 5. 审计验证

```bash
python run.py verify-audit
```

## 6. QA

```bash
python run.py qa
```

QA 使用独立临时数据库，不污染发行目录的运行数据库。报告写入：

```text
outputs/qa_summary.json
```

## 7. 备份

SQLite 处于 WAL 模式。运行中备份应使用 SQLite backup API 或在服务停止后同时处理主数据库和 WAL/SHM 文件。发行包不包含运行数据库。
