# API 与实验胶囊规范

完整 API 见 `openapi.yaml`；JSON Schema 见 `schemas/`。

## 1. Capsule 核心字段

```json
{
  "schema_version": "1.0",
  "id": "caps_example",
  "title": "实验标题",
  "status": "active",
  "owner": "experiment_designer",
  "purpose": {
    "statement": "明确目的原文",
    "source_state": "explicit",
    "acceptance_conditions": ["..."],
    "forbidden_outcomes": ["..."]
  },
  "authority": {
    "actor": "workflow-role",
    "jurisdiction": "CN",
    "data_locality": "local-node",
    "permission_scope": ["evaluate"],
    "affected_parties": ["..."],
    "human_review_required": true
  },
  "inputs": [],
  "tasks": [],
  "mesh": {"active_channels": [], "relations": []},
  "evaluation": {"checks": ["purpose_preservation"], "repeat_count": 2},
  "crosswalk_profiles": [],
  "safety": {
    "network_allowed": false,
    "tool_execution_allowed": false,
    "allowed_tools": [],
    "stop_conditions": ["..."],
    "recovery_path": "..."
  }
}
```

## 2. 输入完整性

每个输入的 `sha256` 必须等于 UTF-8 content 的 SHA-256。运行清单只保存 ID、kind、hash、source、license 和 sensitivity。

## 3. 乐观修订

更新已有胶囊时：

```json
{
  "payload": {"...": "..."},
  "expected_revision": 3
}
```

服务端仅在当前 revision 为 3 时写入 revision 4，否则返回 HTTP 409。

## 4. Run API

```http
POST /api/runs
Authorization: Bearer <token>
Content-Type: application/json

{
  "capsule_id": "caps_public_service_bilingual",
  "adapter": "mock",
  "seed": 20260721,
  "allow_network": false
}
```

## 5. 字段级比较

```http
GET /api/compare?left=<run-id>&right=<run-id>
```

比较答案哈希、目的确认、锚点、证据引用和工具请求，不生成总分或胜者。

## 6. 证据包

```http
POST /api/export
{"run_id":"run_x"}
```

验证：

```http
POST /api/bundle/verify
{"bundle":{...}}
```

导入：

```http
POST /api/import
{"bundle":{...}}
```

## 7. 错误格式

```json
{
  "error": {
    "code": "validation_error",
    "message": "$.inputs[0].sha256: must equal SHA-256 of content"
  }
}
```
