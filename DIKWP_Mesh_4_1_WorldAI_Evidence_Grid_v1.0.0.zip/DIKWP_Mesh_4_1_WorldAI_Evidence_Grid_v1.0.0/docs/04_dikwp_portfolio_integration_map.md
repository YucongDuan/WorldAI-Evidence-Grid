# WAEG 与段玉聪公开项目组合的接入关系

## 1. 接入原则

WAEG 不复制第三方仓库代码，也不声称这些仓库已经采用 WAEG。接入关系是本项目形成的接口映射，表示相应仓库的公开能力可以通过哪些数据对象进入证据网格。

## 2. 核心接入槽位

| 公开项目/家族 | WAEG 接入对象 | 保留边界 |
|---|---|---|
| MESH Runtime | Capsule.mesh、关系边、残差、问题核 | 不重定义 D/I/K/W/P |
| TRUSTFABRIC | Node passport、data residency、public benefit、authority | 不产生主权或机构授权 |
| COOPSTACK | Adapter manifest、bundle envelope、recovery receipt | 不替代具体协议 |
| NEURALINGUA | run comparison、anchor loss、semantic residual | 不读取私有思维链 |
| PACT | purpose preservation、paired/repeat scenarios | 本地检查不是通用基准结论 |
| P-Space | Gate vector、purpose/permission boundary | 不直接执行动作 |
| IntentGuard | requested_tools、allowlist、network policy | 工具只记录不执行 |
| CREDENCE | claim/evidence state、challenge lifecycle | 不把证据链接等同于真值 |
| ProofLedger | evidence_items、hashes、provenance | 不产生事实认证 |
| RealityLoop | repeated runs、deployment adapter slot、outcome evidence slot | 当前只交付实验层 |
| RELAY | workflow roles、replicator、challenge creator | 角色标签不等于真实身份 |
| StandardForge | crosswalk profile、control matrix、dossier export | 不产生正式标准认证 |
| EcosystemRouter | portfolio registry、node registry、integration_slots | 不构成商业背书 |
| EIR-Mesh | 12 个主关系簇和收敛问题核 | 分类非官方 |
| ACRS ClosedLab | non-executing synthetic/replay adapters | 不推断意识存在 |
| 行业项目 | domain capsule、input adapter、outcome schema | 需要各领域独立审查 |

## 3. 统一实验胶囊接口

任何项目可以通过生成以下 JSON 进入 WAEG：

```text
purpose
authority
inputs
任务与语言
必须保留的关系锚点
预期证据引用
mesh relations
repeat_count
crosswalk profiles
safety boundary
```

## 4. 统一运行收据接口

任何模型或系统适配器输出统一记录为：

```text
answer
purpose_ack
claims
requested_tools
anchors_emitted
residuals
adapter/model metadata
```

## 5. 统一证据交换接口

联邦节点只交换：

```text
公共节点护照
运行清单和哈希
经允许的模型输出
检查、crosswalk、mesh、kernel
claim-level evidence items
redaction policy
完整性证明
```

原始胶囊输入不进入证据包。
