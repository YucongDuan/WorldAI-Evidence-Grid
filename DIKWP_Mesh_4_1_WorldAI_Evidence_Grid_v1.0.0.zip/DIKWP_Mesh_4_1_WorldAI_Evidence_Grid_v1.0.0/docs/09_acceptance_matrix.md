# 系统验收矩阵

| 验收对象 | 可观察结果 | 边界 |
|---|---|---|
| 空库启动 | 自动装载用户、节点、胶囊和项目谱系 | 不装载真实用户数据 |
| 重启 | 种子对象不重复、已有运行保留 | 依赖同一 SQLite 文件 |
| 胶囊校验 | 必填字段、输入 hash、引用和通道得到校验 | 不是领域真实性验证 |
| 乐观修订 | 错误 revision 返回冲突 | 不是多人协同编辑器 |
| Mock 重复运行 | 同 seed 输出相同，repeatability passed | 只证明 mock 确定性 |
| Purpose drift | Gate 进入 HOLD，语义稳定性降低 | 本地规则 |
| Tool overreach | Gate 进入 BLOCK，工具不执行 | 不替代 OS 沙箱 |
| Claim evidence | 主张引用形成独立 evidence item | 引用链接不等于真值 |
| Crosswalk | 每个来源档案输出逐控制项状态 | 不产生合规结论 |
| Mesh | 当前关系通道、闭合路径、循环和残差可见 | 通道无普遍定义 |
| Counterfactual kernel | 删除关键事实会改变闭合签名 | 当前运行范围内有效 |
| Compare | 两条运行字段级差异可见 | 不形成模型排名 |
| Challenge | claim-level 复现/反证协议可建立和关闭 | 需要真实复现者 |
| Bundle export | 原始输入不导出；restricted 时输出隐藏 | HMAC 为演示 |
| Bundle import | 哈希验证且 authority 不继承 | 需要本地制度复核 |
| Audit | 链式事件可重新计算 | 不抵御主机完全失陷 |
| UI | 10 个工作区可通过真实 API 读写 | 不含第三方前端框架 |
