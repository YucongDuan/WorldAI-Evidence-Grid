# 中国与全球 AI 治理材料交叉映射

## 1. 映射原则

WAEG 不把政策、标准、风险框架和法律制度混合成统一“全球规则”。每个 profile 保留来源 URL、法域、来源状态、控制项和边界。一个运行事实可以同时进入多个 profile，但不能因此推断规则等价。

结果状态：

```text
observed       所需运行事实全部存在
partial        部分存在
missing        未观察到所需事实
not_applicable 当前版本保留字段，默认不自动推断
contested      当前版本保留字段，默认不自动推断
```

## 2. 中国智能体互联

来源：

- 国家标准全文公开系统相关标准页
- 国家科技信息平台关于《人工智能 智能体互联》系列国家标准的信息

本地映射对象：

```text
身份码和身份材料
能力与限制描述
发现和供需匹配
交互消息及上下文追踪
工具调用权限与审计
全生命周期安全、可靠、可信材料
```

WAEG 当前提供身份句柄、节点护照、能力列表、运行清单、工具请求记录、权限检查、审计和停止/恢复记录，但不是该系列标准的正式实现或一致性认证。

## 3. 中国“人工智能+”与国际公共产品

来源：国务院关于深入实施“人工智能+”行动的公开文件。

本地映射对象：

```text
公共利益声明
可导出的脱敏证据包
开源许可证和文档
本地分叉能力
离线和低资源运行
语言语境
治理和标准对接
安全、可靠、可控材料
```

## 4. 中国人工智能全球治理行动计划

来源：中华人民共和国外交部公开行动计划。

本地映射对象：

```text
跨模型互操作材料
开放文档和接口
数据 provenance、敏感度、脱敏和语言多样性
延迟/CPU 资源观测
标准协调、审计和人工复核
```

当前系统只测量 wall time 和 process CPU time，不测量真实能耗，因此 profile 中的“绿色 AI”只能形成部分工程材料。

## 5. NIST AI RMF / Generative AI Profile

来源：NIST 官方 AI RMF、Generative AI Profile 和 AIRC。

WAEG 将运行事实组织为：

```text
Govern：角色、目的、人工复核和事件路径
Map：语境、受影响方、数据来源和风险场景
Measure：重复性、延迟、证据和挑战
Manage：Gate、停止、恢复和审计
```

这只是工程 crosswalk，不是 NIST 认可、测评或风险结论。

## 6. EU GPAI Code / AI Act

来源：欧盟委员会数字战略官方页面。

本地映射对象：

```text
模型、用途和输出透明
来源和版权政策
风险、事件和挑战材料
人类监督和部署后监测材料
```

WAEG 不判断系统是否落入具体法律角色、是否属于 GPAI 或系统性风险模型，也不提供法律意见。

## 7. UN Global Dialogue on AI Governance

来源：联合国全球 AI 治理对话官方页面。

本地映射对象：

```text
安全、可靠、可信和方法互操作
能力建设、可接入性和开放资源
文化、语言和多元语境
透明、问责和实质性人类监督
```

## 8. 共同证据对象与差异保留

共同运行事实包括：

- purpose contract；
- actor/model/node/adapter identity；
- input/output hashes；
- provenance；
- tool authorization；
- human review；
- stop/recovery；
- audit；
- repeatability；
- language/context；
- public benefit；
- redaction；
- challenge route。

不同制度对这些事实的适用范围、证明标准和法律效果不同。WAEG 只保留映射关系和缺口，不进行制度同一化。
